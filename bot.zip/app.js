const sqlite3 = require('sqlite3').verbose();
const { Telegraf, Scenes, session } = require('telegraf');
const moment = require('moment');
const { createvmess } = require('./create/createvmess');
const { createvless } = require('./create/createvless');
const { createtrojan } = require('./create/createtrojan');
const { createshadowsocks } = require('./create/createshadowsocks');
// import create modules
const { createssh } = require('./create/createssh');
const { checkvmess } = require('./check/checkvmess');
const { checkvless } = require('./check/checkvless');
const { checktrojan } = require('./check/checktrojan');
const { checkshadowsocks } = require('./check/checkshadowsock');
const { checkssh } = require('./check/checkssh');
// import renew modules
const { renewvmess } = require('./renew/renewvmess');
const { renewvless } = require('./renew/renewvless');
const { renewtrojan } = require('./renew/renewtrojan');
const { renewshadowsocks } = require('./renew/renewshadowsocks');
const { renewssh } = require('./renew/renewssh');
// import delete modules
const { deletevmess } = require('./delete/deletevmess');
const { deletevless } = require('./delete/deletevless');
const { deletetrojan } = require('./delete/deletetrojan');
const { deleteshadowsocks } = require('./delete/deleteshadowsocks');
const { deletessh } = require('./delete/deletessh');

const { createzivpn } = require('./create/createzivpn');
const { deletezivpn } = require('./delete/deletezivpn');
const { renewzivpn } = require('./renew/renewzivpn');


const { BOT_TOKEN, ADMIN } = require('/root/.bot/.vars.json');
const bot = new Telegraf(BOT_TOKEN);
// Daftar ID admin yang diizinkan
const adminIds = ADMIN; // Ganti dengan ID admin yang diizinkan
console.log('Bot initialized');

// Koneksi ke SQLite3
const db = new sqlite3.Database('./database.db', (err) => {
  if (err) {
    console.error('Kesalahan koneksi SQLite3:', err.message);
  } else {
    console.log('Terhubung ke SQLite3');
  }
});

// Buat tabel Server jika belum ada
db.run(`CREATE TABLE IF NOT EXISTS Server (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  domain TEXT,
  auth TEXT
)`, (err) => {
  if (err) {
    console.error('Kesalahan membuat tabel Server:', err.message);
  } else {
    console.log('Server table created or already exists');
  }
});

// Menyimpan state pengguna
const userState = {};
console.log('User state initialized');

// Tambahkan command menu dan start
bot.command('menu', async (ctx) => {
  console.log('Menu command received');
  await sendMainMenu(ctx);
});

bot.command('start', async (ctx) => {
  console.log('Start command received');
  await sendMainMenu(ctx);
});

bot.command('admin', async (ctx) => {
  console.log('Admin menu requested');
  
  if (!adminIds.includes(ctx.from.id)) {
    await ctx.reply('Anda tidak memiliki izin untuk mengakses menu admin.');
    return;
  }

  await sendAdminMenu(ctx);
});

async function sendMainMenu(ctx) {
  const keyboard = [
    [
      { text: '✨ Create Service', callback_data: 'service_create' },
      { text: '🗑️ Delete Service', callback_data: 'service_delete' },
    ],
    [
      { text: '🔄 Renew Service', callback_data: 'service_renew' },
      { text: '📊 Check Service', callback_data: 'service_check' }
    ],
    [
      { text: '🎁 Trial Service', callback_data: 'service_trial' }
    ]
  ];

  const currentTime = new Date().toLocaleString('id-ID', { 
    timeZone: 'Asia/Jakarta',
    hour: '2-digit',
    minute: '2-digit',
    day: '2-digit',
    month: 'long',
    year: 'numeric'
  });

  const messageText = `
🚀 *XTRVPN BOT*

*Layanan VPN Premium*
Fast • Secure • Reliable

🕐 *Waktu Server*
${currentTime}

💎 *Pilih Layanan*
Kelola akun VPN kamu dengan mudah dan cepat

👇 Pilih menu di bawah ini untuk memulai
`;

  try {
    await ctx.editMessageText(messageText, {
      parse_mode: 'Markdown',
      reply_markup: {
        inline_keyboard: keyboard
      }
    });
    console.log('Main menu sent');
  } catch (error) {
    if (error.response && error.response.error_code === 400) {
      await ctx.reply(messageText, {
        parse_mode: 'Markdown',
        reply_markup: {
          inline_keyboard: keyboard
        }
      });
      console.log('Main menu sent as new message');
    } else {
      console.error('Error saat mengirim menu utama:', error);
    }
  }
}

/// Fungsi untuk menangani semua jenis layanan
async function handleServiceAction(ctx, action) {
  let keyboard;
  if (action === 'create') {
    keyboard = [
      [{ text: '🔐 Create SSH', callback_data: 'create_ssh' }],      
      [{ text: '📡 Create Vmess', callback_data: 'create_vmess' }],
      [{ text: '⚡ Create Vless', callback_data: 'create_vless' }],
      [{ text: '🛡️ Create Trojan', callback_data: 'create_trojan' }],
      [{ text: '🌐 Create Shadowsocks', callback_data: 'create_shadowsocks' }],
      [{ text: '✨ Create ZIVPN', callback_data: 'create_zivpn' }],
      [{ text: '🔙 Kembali', callback_data: 'send_main_menu' }]
    ];
  } else if (action === 'delete') {
    keyboard = [
      [{ text: '🔐 Delete SSH', callback_data: 'delete_ssh' }],      
      [{ text: '📡 Delete Vmess', callback_data: 'delete_vmess' }],
      [{ text: '⚡ Delete Vless', callback_data: 'delete_vless' }],
      [{ text: '🛡️ Delete Trojan', callback_data: 'delete_trojan' }],
      [{ text: '🌐 Delete Shadowsocks', callback_data: 'delete_shadowsocks' }],
      [{ text: '✨ Delete ZIVPN', callback_data: 'delete_zivpn' }],
      [{ text: '🔙 Kembali', callback_data: 'send_main_menu' }]
    ];
  } else if (action === 'renew') {
    keyboard = [
      [{ text: '🔐 Renew SSH', callback_data: 'renew_ssh' }],      
      [{ text: '📡 Renew Vmess', callback_data: 'renew_vmess' }],
      [{ text: '⚡ Renew Vless', callback_data: 'renew_vless' }],
      [{ text: '🛡️ Renew Trojan', callback_data: 'renew_trojan' }],
      [{ text: '🌐 Renew Shadowsocks', callback_data: 'renew_shadowsocks' }],
      [{ text: '✨ Renew ZIVPN', callback_data: 'renew_zivpn' }],
      [{ text: '🔙 Kembali', callback_data: 'send_main_menu' }]
    ];
  } else if (action === 'check') {
    keyboard = [
      [{ text: '🔐 Check SSH', callback_data: 'check_ssh' }],      
      [{ text: '📡 Check Vmess', callback_data: 'check_vmess' }],
      [{ text: '⚡ Check Vless', callback_data: 'check_vless' }],
      [{ text: '🛡️ Check Trojan', callback_data: 'check_trojan' }],
      [{ text: '🌐 Check Shadowsocks', callback_data: 'check_shadowsocks' }],      
      [{ text: '🔙 Kembali', callback_data: 'send_main_menu' }]
    ];
  }

  try {
    await ctx.editMessageReplyMarkup({
      inline_keyboard: keyboard
    });
    console.log(`${action} service menu sent`);
  } catch (error) {
    if (error.response && error.response.error_code === 400) {
      await ctx.reply(`Pilih jenis layanan yang ingin Anda ${action}:`, {
        reply_markup: {
          inline_keyboard: keyboard
        }
      });
      console.log(`${action} service menu sent as new message`);
    } else {
      console.error(`Error saat mengirim menu ${action}:`, error);
    }
  }
}

async function sendAdminMenu(ctx) {
  const adminKeyboard = [
    [{ text: '➕ Tambah Server', callback_data: 'addserver' }],
    [{ text: '❌ Hapus Server', callback_data: 'deleteserver' }],   
    [{ text: '📜 List Server', callback_data: 'listserver' }],     
    [{ text: '🗑️ Reset Server', callback_data: 'resetdb' }],
    [{ text: '🔙 Kembali', callback_data: 'send_main_menu' }]
  ];

  try {
    await ctx.editMessageReplyMarkup({
      inline_keyboard: adminKeyboard
    });
    console.log('Admin menu sent');
  } catch (error) {
    if (error.response && error.response.error_code === 400) {
      // Jika pesan tidak dapat diedit, kirim pesan baru
      await ctx.reply('Menu Admin:', {
        reply_markup: {
          inline_keyboard: adminKeyboard
        }
      });
      console.log('Admin menu sent as new message');
    } else {
      console.error('Error saat mengirim menu admin:', error);
    }
  }
}

bot.action('service_trial', async (ctx) => {
  const keyboard = [
    [{ text: '🔐 Trial SSH', callback_data: 'trial_ssh' }],
    [{ text: '📡 Trial Vmess', callback_data: 'trial_vmess' }],
    [{ text: '⚡ Trial Vless', callback_data: 'trial_vless' }],
    [{ text: '🛡️ Trial Trojan', callback_data: 'trial_trojan' }],
    [{ text: '🌐 Trial Shadowsocks', callback_data: 'trial_shadowsocks' }],
    [{ text: '✨ Trial ZIVPN', callback_data: 'trial_zivpn' }],
    [{ text: '🔙 Kembali', callback_data: 'send_main_menu' }]
  ];
  try {
    await ctx.editMessageReplyMarkup({ inline_keyboard: keyboard });
  } catch (err) {
    // fallback kirim baru
    await ctx.reply('Pilih jenis trial:', {
      reply_markup: { inline_keyboard: keyboard }
    });
  }
});

// Reuse startSelectServer untuk daftar server — panggil dengan action 'trial'
bot.action('trial_vmess', async (ctx) => { await startSelectServer(ctx, 'trial', 'vmess'); });
bot.action('trial_vless', async (ctx) => { await startSelectServer(ctx, 'trial', 'vless'); });
bot.action('trial_trojan', async (ctx) => { await startSelectServer(ctx, 'trial', 'trojan'); });
bot.action('trial_shadowsocks', async (ctx) => { await startSelectServer(ctx, 'trial', 'shadowsocks'); });
bot.action('trial_ssh', async (ctx) => { await startSelectServer(ctx, 'trial', 'ssh'); });
bot.action('trial_zivpn', async (ctx) => { await startSelectServer(ctx, 'trial', 'zivpn'); });

// Action handlers untuk semua jenis layanan
bot.action('service_create', async (ctx) => {
  await handleServiceAction(ctx, 'create');
});

bot.action('service_delete', async (ctx) => {
  await handleServiceAction(ctx, 'delete');
});

bot.action('service_renew', async (ctx) => {
  await handleServiceAction(ctx, 'renew');
});

bot.action('service_check', async (ctx) => {
  await handleServiceAction(ctx, 'check');
});

// Action handler untuk kembali ke menu utama
bot.action('send_main_menu', async (ctx) => {
  await sendMainMenu(ctx);
});

// Action handlers for creating accounts
bot.action('create_vmess', async (ctx) => {
  await startSelectServer(ctx, 'create', 'vmess');
});

bot.action('create_vless', async (ctx) => {
  await startSelectServer(ctx, 'create', 'vless');
});

bot.action('create_trojan', async (ctx) => {
  await startSelectServer(ctx, 'create', 'trojan');
});

bot.action('create_shadowsocks', async (ctx) => {
  await startSelectServer(ctx, 'create', 'shadowsocks');
});

bot.action('create_ssh', async (ctx) => {
  await startSelectServer(ctx, 'create', 'ssh');
});
// ZIVPN
bot.action('create_zivpn', async (ctx) => { await startSelectServer(ctx, 'create', 'zivpn'); });
bot.action('delete_zivpn', async (ctx) => { await startSelectServer(ctx, 'delete', 'zivpn'); });
bot.action('renew_zivpn', async (ctx) => { await startSelectServer(ctx, 'renew', 'zivpn'); });

// Action handlers for deleting accounts
bot.action('delete_vmess', async (ctx) => {
  await startSelectServer(ctx, 'delete', 'vmess');
});

bot.action('delete_vless', async (ctx) => {
  await startSelectServer(ctx, 'delete', 'vless');
});

bot.action('delete_trojan', async (ctx) => {
  await startSelectServer(ctx, 'delete', 'trojan');
});

bot.action('delete_shadowsocks', async (ctx) => {
  await startSelectServer(ctx, 'delete', 'shadowsocks');
});

bot.action('delete_ssh', async (ctx) => {
  await startSelectServer(ctx, 'delete', 'ssh');
});

// Action handlers for renewing accounts
bot.action('renew_vmess', async (ctx) => {
  await startSelectServer(ctx, 'renew', 'vmess');
});

bot.action('renew_vless', async (ctx) => {
  await startSelectServer(ctx, 'renew', 'vless');
});

bot.action('renew_trojan', async (ctx) => {
  await startSelectServer(ctx, 'renew', 'trojan');
});

bot.action('renew_shadowsocks', async (ctx) => {
  await startSelectServer(ctx, 'renew', 'shadowsocks');
});

bot.action('renew_ssh', async (ctx) => {
  await startSelectServer(ctx, 'renew', 'ssh');
});
// Action handlers for checking accounts
bot.action('check_vmess', async (ctx) => {
  await startSelectServer(ctx, 'check', 'vmess');
});

bot.action('check_vless', async (ctx) => {
  await startSelectServer(ctx, 'check', 'vless');
});

bot.action('check_trojan', async (ctx) => {
  await startSelectServer(ctx, 'check', 'trojan');
});

bot.action('check_shadowsocks', async (ctx) => {
  await startSelectServer(ctx, 'check', 'shadowsocks');
});

bot.action('check_ssh', async (ctx) => {
  await startSelectServer(ctx, 'check', 'ssh');
});
// --- START: Trial via API (ganti handler trial lama) ---
const http = require('http');
const https = require('https');

function httpGetJson(url, timeout = 10_000) {
  return new Promise((resolve, reject) => {
    try {
      const lib = url.startsWith('https://') ? https : http;
      const req = lib.get(url, { timeout }, (res) => {
        let data = '';
        res.on('data', chunk => data += chunk);
        res.on('end', () => {
          // try parse JSON (clean trailing commas if any)
          try {
            const cleaned = data.replace(/,\s*}/g, '}').replace(/,\s*]/g, ']');
            const j = JSON.parse(cleaned);
            resolve(j);
          } catch (err) {
            // not JSON or parse error -> return raw
            resolve({ __raw: data, __parseError: err.message });
          }
        });
      });
      req.on('error', (err) => reject(err));
      req.on('timeout', () => { req.destroy(); reject(new Error('timeout')); });
    } catch (err) {
      reject(err);
    }
  });
}

// === Trial handler (FULL BOX untuk semua protokol, sesuai output API scripts) ===
const crypto = require('crypto'); // pastikan tersedia di context bot

bot.action(/(trial)_username_(vmess|vless|trojan|shadowsocks|ssh|zivpn)_(.+)/, async (ctx) => {
  const action = ctx.match[1];
  const type = ctx.match[2];
  const serverId = ctx.match[3];
  
  // Simpan state untuk menangkap input menit di bot.on('text')
  userState[ctx.chat.id] = { 
    step: `trial_duration_${type}`, 
    serverId, 
    type, 
    action 
  };

  await ctx.answerCbQuery().catch(() => {});
  await ctx.reply(`⏳ Anda memilih Trial *${type.toUpperCase()}*.\nSilakan masukkan durasi menit (contoh: 30 atau 60):`, { parse_mode: 'Markdown' });
});

// --- END: Trial via API ---
// Function to start selecting a server
async function startSelectServer(ctx, action, type) {
  try {
    console.log(`Memulai proses ${action} untuk ${type}`);
    
    db.all('SELECT * FROM Server', [], (err, servers) => {
      if (err) {
        console.error('Error fetching servers:', err.message);
        return ctx.reply('⚠️ PERHATIAN! Tidak ada server yang tersedia saat ini. Coba lagi nanti!');
      }

      if (servers.length === 0) {
        console.log('Tidak ada server yang tersedia');
        return ctx.reply('⚠️ PERHATIAN! Tidak ada server yang tersedia saat ini. Coba lagi nanti!');
      }

      const keyboard = servers.map(server => {
        return [{ text: server.domain, callback_data: `${action}_username_${type}_${server.id}` }];
      });
      keyboard.push([{ text: '🔙 Kembali ke Menu Utama', callback_data: 'send_main_menu' }]);

      ctx.answerCbQuery();
      ctx.deleteMessage();
      ctx.reply('Pilih server:', {
        reply_markup: {
          inline_keyboard: keyboard
        }
      });

      // Menyimpan state pengguna
      userState[ctx.chat.id] = { step: `${action}_username_${type}` };
    });
  } catch (error) {
    console.error(`Error saat memulai proses ${action} untuk ${type}:`, error);
    await ctx.reply(`❌ GAGAL! Terjadi kesalahan saat memproses permintaan Anda. Silakan coba lagi nanti.`);
  }
}
// Handle server selection
bot.action(/(create|delete|renew|check)_username_(vmess|vless|trojan|shadowsocks|ssh|zivpn)_(.+)/, async (ctx) => {
  const action = ctx.match[1];
  const type = ctx.match[2];
  const serverId = ctx.match[3];
  
  userState[ctx.chat.id] = { step: `username_${action}_${type}`, serverId, type, action };
  
  if (action === 'check') {
    let msg;
    if (type === 'vmess') {
      msg = await checkvmess(serverId);
    } else if (type === 'vless') {
      msg = await checkvless(serverId);
    } else if (type === 'trojan') {
      msg = await checktrojan(serverId);
    } else if (type === 'shadowsocks') {
      msg = await checkshadowsocks(serverId);
    } else if (type === 'ssh') {
      msg = await checkssh(serverId);
    } else if (type === 'zivpn') {
      // Karena kamu gak mau pasang check zivpn, kita kasih pesan info aja
      msg = "❌ Fitur check untuk ZIVPN tidak tersedia.";
    }

    await ctx.reply(msg || "⚠️ Data tidak ditemukan", { parse_mode: 'Markdown' });
    delete userState[ctx.chat.id];
  } else {
    // Jika bukan check (berarti create, delete, atau renew)
    const promptMsg = (type === 'zivpn') ? '🔐 Masukkan Password ZIVPN:' : '👤 Masukkan Username:';
    await ctx.reply(promptMsg);
  }
});
// Helper untuk memotong link yang kepanjangan
const trunc = (s, n = 2500) => (typeof s === 'string' && s.length > n ? s.slice(0, n) + '...(truncated)' : s);

// Helper untuk ambil port secara dinamis
const Pget = (d, k, fallback) => {
  if (!d) return typeof fallback !== 'undefined' ? fallback : '-';
  if (d.ports && (d.ports[k] || d.ports[k.toLowerCase()])) return d.ports[k] || d.ports[k.toLowerCase()];
  if (d[k]) return d[k]; // Cek juga di root object
  return typeof fallback !== 'undefined' ? fallback : '-';
};

function formatMessage(d = {}, proto = 'unknown', domain = 'unknown') {
  const expire = d.expiration || d.exp || d.expired || '-';
  const ip = d.ip || '-';
  const city = d.city || '-';
  const ns = d.ns_domain || d.ns || '-';
  const pubKey = d.public_key || d.pubkey || '-';

  let msg = '☀ *Trial Berhasil Dibuat!* \n';
  msg += '🖥️ *Server:* `' + domain + '` \n';
  msg += '📍 *City:* `' + city + '` \n';
  msg += '⏳ *Expired:* `' + expire + '` \n\n';

  // ==========================
  // ZIVPN
  // ==========================
  if (proto === 'zivpn') {
    msg += '┌─────────────────────\n';
    msg += '│       *AKUN ZIVPN* \n';
    msg += '│ *Password* : `' + (d.password || '-') + '`\n';
    msg += '│ *IP Limit* : `' + (d.ip_limit || d.iplimit || '-') + '`\n';
    msg += '│ *Durasi* : `' + (d.duration_minutes || d.duration || '-') + ' Menit`\n';
    msg += '└─────────────────────\n\n';
    msg += 'ℹ️ _Gunakan password di atas pada aplikasi ZIVPN Anda._\n';
  } 

  // ==========================
  // SSH
  // ==========================
  else if (proto === 'ssh') {
    msg += '┌─────────────────────\n';
    msg += '│ *Username* : `' + (d.username || '-') + '`\n';
    msg += '│ *Password* : `' + (d.password || d.pass || '-') + '`\n';
    msg += '└─────────────────────\n';
    msg += '┌─────────────────────\n';
    msg += '│ *Host* : `' + domain + '` (`' + ip + '`)\n';
    msg += '│ *Port TLS* : `' + Pget(d, 'ssl_tls', '443') + '`\n';
    msg += '│ *Port HTTP*: `' + Pget(d, 'http', '80') + '`\n';
    msg += '│ *Port Udp* : `7100, 7200, 7300`\n';
    msg += '└─────────────────────\n\n';
    if (d.wss_payload) msg += '📦 *WSS Payload:*\n`' + d.wss_payload + '`\n\n';
    if (d.openvpn_link) msg += '🔗 *OpenVPN:* [Download Link](' + d.openvpn_link + ')\n\n';
  } 

  // ==========================
  // VMESS / VLESS / TROJAN
  // ==========================
  else if (proto === 'vmess' || proto === 'vless' || proto === 'trojan') {
    const userId = d.uuid || d.password || d.pass || '-';
    msg += '┌─────────────────────\n';
    msg += `│ *Akun ${proto.toUpperCase()}*\n`;
    msg += '│ *User* : `' + (d.username || '-') + '`\n';
    msg += '│ *UUID* : `' + userId + '`\n';
    if (ns !== '-') msg += '│ *NS Dom* : `' + ns + '`\n';
    if (pubKey !== '-') msg += '│ *Pub Key*: `' + pubKey + '`\n';
    msg += '└─────────────────────\n\n';

    if (d.link_tls) msg += '🔐 *TLS Link:*\n```\n' + trunc(d.link_tls) + '\n```\n';
    if (d.link_ntls) msg += '🔓 *Non-TLS Link:*\n```\n' + trunc(d.link_ntls) + '\n```\n';
    if (d.link_grpc) msg += '🚀 *gRPC Link:*\n```\n' + trunc(d.link_grpc) + '\n```\n';
  }

  // ==========================
  // SHADOWSOCKS
  // ==========================
  else if (proto === 'shadowsocks' || proto === 'ss') {
    msg += '┌─────────────────────\n';
    msg += '│ *Akun Shadowsocks*\n';
    msg += '│ *Password* : `' + (d.password || '-') + '`\n';
    msg += '│ *Method* : `' + (d.method || 'aes-128-gcm') + '`\n';
    msg += '└─────────────────────\n\n';
    if (d.link_ws || d.link) msg += '🔗 *SS Link:*\n```\n' + trunc(d.link_ws || d.link) + '\n```\n';
  }

  msg += '\n✨ Selamat menggunakan layanan kami! ✨';
  return msg;
}


// Handle text input for various steps
bot.on('text', async (ctx) => {
  const state = userState[ctx.chat.id];
  if (!state) return;

  const input = ctx.message.text.trim();
  const { type, action, serverId } = state;
if (state && state.step && state.step.startsWith('trial_duration_')) {
  const duration = ctx.message.text.trim();
  if (!/^\d+$/.test(duration)) return ctx.reply('❌ Gunakan angka saja untuk menit!');

  const { type, serverId } = state;
  await ctx.reply('🚀 Sedang memproses trial...');

  // --- LOGIKA API PINDAH KE SINI ---
  db.get('SELECT * FROM Server WHERE id = ?', [serverId], async (err, server) => {
    if (err || !server) {
      delete userState[ctx.chat.id];
      return ctx.reply('❌ Server tidak ditemukan.');
    }

    const domain = server.domain;
    const auth = server.auth || '';
    const routeMap = {
      ssh: 'trialssh', vmess: 'trialvmess', vless: 'trialvless',
      trojan: 'trialtrojan', shadowsocks: 'trialshadowsocks', zivpn: 'trialzivpn'
    };

    // Tambahkan durasi ke URL API
    let url = `http://${domain}:5888/${routeMap[type]}?auth=${encodeURIComponent(auth)}&duration=${duration}`;
    
    // Generate username random
    const generatedUsername = 'trial' + Math.floor(1000 + Math.random() * 9000);
    url += `&username=${generatedUsername}`;

    try {
      const json = await httpGetJson(url, 15000);
      if (json && json.status === 'success') {
        const data = json.data || json;
        // Panggil fungsi formatMessage yang kamu buat tadi
        const message = formatMessage(data, type, domain);
        await ctx.reply(message, { parse_mode: 'Markdown' });
      } else {
        await ctx.reply(`❌ Gagal: ${json.message || 'API Error'}`);
      }
    } catch (e) {
      await ctx.reply('❌ Error: ' + e.message);
    } finally {
      delete userState[ctx.chat.id];
    }
  });
  return; // Stop agar tidak lanjut ke logika username
}

  // STEP 1: Masukkan Username / Password Utama
  if (state.step.startsWith('username_')) {
    state.username = input; // Untuk ZIVPN, input ini berfungsi sebagai password
    
    if (action === 'delete') {
      let msg;
      // Langsung eksekusi hapus karena hanya butuh 1 parameter
      if (type === 'zivpn') msg = await deletezivpn(input, serverId);
      else if (type === 'ssh') msg = await deletessh(input, serverId);
      else if (type === 'vmess') msg = await deletevmess(input, serverId);
      else if (type === 'vless') msg = await deletevless(input, serverId);
      else if (type === 'trojan') msg = await deletetrojan(input, serverId);
      else if (type === 'shadowsocks') msg = await deleteshadowsocks(input, serverId);
      
      await ctx.reply(msg || "❌ Gagal menghapus.", { parse_mode: 'Markdown' });
      return delete userState[ctx.chat.id];
    }

    if (action === 'create' && type === 'ssh') {
      state.step = `password_${action}_${type}`;
      await ctx.reply('🔑 Masukkan password SSH:');
    } else {
      // Create/Renew untuk ZIVPN, Vmess, dll langsung ke Expired
      state.step = `exp_${action}_${type}`;
      await ctx.reply('⏳ Masukkan masa aktif (hari):');
    }
  }

  // STEP 2: Password (Hanya untuk SSH Create)
  else if (state.step.startsWith('password_')) {
    state.password = input;
    state.step = `exp_${action}_${type}`;
    await ctx.reply('⏳ Masukkan masa aktif (hari):');
  }

  // STEP 3: Masa Aktif (Expired)
  else if (state.step.startsWith('exp_')) {
    if (!/^\d+$/.test(input)) return ctx.reply('❌ Gunakan angka saja!');
    state.exp = input;

    // JALUR KHUSUS: SSH dan ZIVPN tidak pakai Quota
    if (type === 'ssh' || type === 'zivpn') {
      state.step = `limitip_${action}_${type}`;
      await ctx.reply('🔢 Masukkan limit IP:');
    } else {
      state.step = `quota_${action}_${type}`;
      await ctx.reply('📊 Masukkan quota (GB):');
    }
  }

  // STEP 4: Quota (Hanya untuk Vmess, Vless, Trojan, SS)
  else if (state.step.startsWith('quota_')) {
    if (!/^\d+$/.test(input)) return ctx.reply('❌ Gunakan angka saja!');
    state.quota = input;
    state.step = `limitip_${action}_${type}`;
    await ctx.reply('🔢 Masukkan limit IP:');
  }

  // STEP 5: Limit IP (Final Eksekusi Create & Renew)
  else if (state.step.startsWith('limitip_')) {
    if (!/^\d+$/.test(input)) return ctx.reply('❌ Gunakan angka saja!');
    state.limitip = input;
    
    let msg;
    const { username, password, exp, quota, limitip } = state;

    if (action === 'create') {
      if (type === 'zivpn') msg = await createzivpn(username, exp, limitip, serverId);
      else if (type === 'ssh') msg = await createssh(username, password, exp, limitip, serverId);
      else if (type === 'vmess') msg = await createvmess(username, exp, quota, limitip, serverId);
      else if (type === 'vless') msg = await createvless(username, exp, quota, limitip, serverId);
      else if (type === 'trojan') msg = await createtrojan(username, exp, quota, limitip, serverId);
      else if (type === 'shadowsocks') msg = await createshadowsocks(username, exp, quota, limitip, serverId);
    } 
    else if (action === 'renew') {
      if (type === 'zivpn') msg = await renewzivpn(username, exp, limitip, serverId);
      else if (type === 'ssh') msg = await renewssh(username, exp, limitip, serverId);
      else if (type === 'vmess') msg = await renewvmess(username, exp, quota, limitip, serverId);
      else if (type === 'vless') msg = await renewvless(username, exp, quota, limitip, serverId);
      else if (type === 'trojan') msg = await renewtrojan(username, exp, quota, limitip, serverId);
      else if (type === 'shadowsocks') msg = await renewshadowsocks(username, exp, quota, limitip, serverId);
    }

    await ctx.reply(msg || "⚠️ API tidak memberikan respon", { parse_mode: 'Markdown' });
    delete userState[ctx.chat.id];
  }

  // STEP ADMIN: Tambah Server
  else if (state.step === 'addserver') {
    state.domain = input;
    state.step = 'addserver_auth';
    await ctx.reply('🔑 Masukkan auth server (cek di /root/.key VPS):');
  } 
  else if (state.step === 'addserver_auth') {
    db.run('INSERT INTO Server (domain, auth) VALUES (?, ?)', [state.domain, input], (err) => {
      if (err) ctx.reply('❌ Gagal simpan ke database.');
      else ctx.reply(`✅ Server ${state.domain} berhasil ditambahkan.`);
      delete userState[ctx.chat.id];
    });
  }
});

//ADMIN
bot.action('deleteserver', async (ctx) => {
  try {
    console.log('Delete server process started');
    await ctx.answerCbQuery();
    
    db.all('SELECT * FROM Server', [], (err, servers) => {
      if (err) {
        console.error('Error fetching servers:', err.message);
        return ctx.reply('⚠️ PERHATIAN! Terjadi kesalahan saat mengambil daftar server.');
      }

      if (servers.length === 0) {
        console.log('Tidak ada server yang tersedia');
        return ctx.reply('⚠️ PERHATIAN! Tidak ada server yang tersedia saat ini.');
      }

      const keyboard = servers.map(server => {
        return [{ text: server.domain, callback_data: `confirm_delete_server_${server.id}` }];
      });
      keyboard.push([{ text: '🔙 Kembali ke Menu Utama', callback_data: 'kembali_ke_menu' }]);

      ctx.reply('Pilih server yang ingin dihapus:', {
        reply_markup: {
          inline_keyboard: keyboard
        }
      });
    });
  } catch (error) {
    console.error('Kesalahan saat memulai proses hapus server:', error);
    await ctx.reply('❌ GAGAL! Terjadi kesalahan saat memproses permintaan Anda. Silakan coba lagi nanti.');
  }
});

bot.action(/confirm_delete_server_(\d+)/, async (ctx) => {
  try {
    db.run('DELETE FROM Server WHERE id = ?', [ctx.match[1]], function(err) {
      if (err) {
        console.error('Error deleting server:', err.message);
        return ctx.reply('⚠️ PERHATIAN! Terjadi kesalahan saat menghapus server.');
      }

      if (this.changes === 0) {
        console.log('Server tidak ditemukan');
        return ctx.reply('⚠️ PERHATIAN! Server tidak ditemukan.');
      }

      console.log(`Server dengan ID ${ctx.match[1]} berhasil dihapus`);
      ctx.reply('✅ Server berhasil dihapus.');
    });
  } catch (error) {
    console.error('Kesalahan saat menghapus server:', error);
    await ctx.reply('❌ GAGAL! Terjadi kesalahan saat memproses permintaan Anda. Silakan coba lagi nanti.');
  }
});

bot.action('addserver', async (ctx) => {
  try {
    console.log('Add server process started');
    await ctx.answerCbQuery();
    await ctx.reply('🌐 Silakan masukkan domain/ip server:');
    userState[ctx.chat.id] = { step: 'addserver' };
  } catch (error) {
    console.error('Kesalahan saat memulai proses tambah server:', error);
    await ctx.reply('❌ GAGAL! Terjadi kesalahan saat memproses permintaan Anda. Silakan coba lagi nanti.');
  }
});

bot.action('listserver', async (ctx) => {
  try {
    console.log('List server process started');
    await ctx.answerCbQuery();
    
    db.all('SELECT * FROM Server', [], (err, servers) => {
      if (err) {
        console.error('Error fetching servers:', err.message);
        return ctx.reply('⚠️ PERHATIAN! Terjadi kesalahan saat mengambil daftar server.');
      }

      if (servers.length === 0) {
        console.log('Tidak ada server yang tersedia');
        return ctx.reply('⚠️ PERHATIAN! Tidak ada server yang tersedia saat ini.');
      }

      let serverList = '📜 *Daftar Server* 📜\n\n';
      servers.forEach((server, index) => {
        serverList += `${index + 1}. ${server.domain}\n`;
      });

      ctx.reply(serverList, { parse_mode: 'Markdown' });
    });
  } catch (error) {
    console.error('Kesalahan saat mengambil daftar server:', error);
    await ctx.reply('❌ GAGAL! Terjadi kesalahan saat memproses permintaan Anda. Silakan coba lagi nanti.');
  }
});

bot.action('resetdb', async (ctx) => {
  try {
    await ctx.answerCbQuery();
    db.run('DELETE FROM Server', (err) => {
      if (err) {
        console.error('Error saat mereset tabel Server:', err.message);
        ctx.reply('❗️ PERHATIAN! Terjadi KESALAHAN SERIUS saat mereset database. Harap segera hubungi administrator!');
      }
    });
    await ctx.reply('🚨 PERHATIAN! Database telah DIRESET SEPENUHNYA. Semua server telah DIHAPUS TOTAL.');
  } catch (error) {
    console.error('Error saat mereset database:', error);
    await ctx.reply('❗️ PERHATIAN! Terjadi KESALAHAN SERIUS saat mereset database. Harap segera hubungi administrator!');
  }
});

// Mulai bot
bot.launch().then(() => {
  console.log('Bot telah dimulai');
}).catch((error) => {
  console.error('Error saat memulai bot:', error);
});