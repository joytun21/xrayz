const sqlite3 = require('sqlite3').verbose();
const { Telegraf, Scenes, session } = require('telegraf');
const moment = require('moment');
const { createvmess } = require('./create/createvmess');
const { createvless } = require('./create/createvless');
const { createtrojan } = require('./create/createtrojan');
const { createshadowsocks } = require('./create/createshadowsocks');
// import create modules
const { createssh } = require('./create/createssh');
const { checkvmess } = require('./check/checkvmess');
const { checkvless } = require('./check/checkvless');
const { checktrojan } = require('./check/checktrojan');
const { checkshadowsocks } = require('./check/checkshadowsock');
const { checkssh } = require('./check/checkssh');
// import renew modules
const { renewvmess } = require('./renew/renewvmess');
const { renewvless } = require('./renew/renewvless');
const { renewtrojan } = require('./renew/renewtrojan');
const { renewshadowsocks } = require('./renew/renewshadowsocks');
const { renewssh } = require('./renew/renewssh');
// import delete modules
const { deletevmess } = require('./delete/deletevmess');
const { deletevless } = require('./delete/deletevless');
const { deletetrojan } = require('./delete/deletetrojan');
const { deleteshadowsocks } = require('./delete/deleteshadowsocks');
const { deletessh } = require('./delete/deletessh');

const { BOT_TOKEN, ADMIN } = require('/root/.bot/.vars.json');
const bot = new Telegraf(BOT_TOKEN);
// Daftar ID admin yang diizinkan
const adminIds = ADMIN; // Ganti dengan ID admin yang diizinkan
console.log('Bot initialized');

// Koneksi ke SQLite3
const db = new sqlite3.Database('./database.db', (err) => {
  if (err) {
    console.error('Kesalahan koneksi SQLite3:', err.message);
  } else {
    console.log('Terhubung ke SQLite3');
  }
});

// Buat tabel Server jika belum ada
db.run(`CREATE TABLE IF NOT EXISTS Server (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  domain TEXT,
  auth TEXT
)`, (err) => {
  if (err) {
    console.error('Kesalahan membuat tabel Server:', err.message);
  } else {
    console.log('Server table created or already exists');
  }
});

// Menyimpan state pengguna
const userState = {};
console.log('User state initialized');

// Tambahkan command menu dan start
bot.command('menu', async (ctx) => {
  console.log('Menu command received');
  await sendMainMenu(ctx);
});

bot.command('start', async (ctx) => {
  console.log('Start command received');
  await sendMainMenu(ctx);
});

bot.command('admin', async (ctx) => {
  console.log('Admin menu requested');
  
  if (!adminIds.includes(ctx.from.id)) {
    await ctx.reply('Anda tidak memiliki izin untuk mengakses menu admin.');
    return;
  }

  await sendAdminMenu(ctx);
});

async function sendMainMenu(ctx) {
  const keyboard = [
  [
    { text: '🍏 Service Create', callback_data: 'service_create' },
    { text: '🍎 Service Delete', callback_data: 'service_delete' },
  ],
  [
    { text: '🍊 Service Renew', callback_data: 'service_renew' },
    { text: '🍌 Service Check', callback_data: 'service_check' }
  ],
  [
    { text: '🎯 Trial Service', callback_data: 'service_trial' }
  ]
];


  const currentTime = new Date().toLocaleString('id-ID', { timeZone: 'Asia/Jakarta' });
  const messageText = `
🌐 **Selamat Datang di XTRVPN BOT** 🚀  
Layanan manajemen VPN otomatis, cepat, dan stabil untuk kebutuhan harian kamu.

🕒 **Waktu Saat Ini:** *${currentTime}*

✨ Silakan pilih layanan yang ingin kamu gunakan:
`;

  try {
    await ctx.editMessageText(messageText, {
      parse_mode: 'Markdown',
      reply_markup: {
        inline_keyboard: keyboard
      }
    });
    console.log('Main menu sent');
  } catch (error) {
    if (error.response && error.response.error_code === 400) {
      // Jika pesan tidak dapat diedit, kirim pesan baru
      await ctx.reply(messageText, {
        parse_mode: 'Markdown',
        reply_markup: {
          inline_keyboard: keyboard
        }
      });
      console.log('Main menu sent as new message');
    } else {
      console.error('Error saat mengirim menu utama:', error);
    }
  }
}

/// Fungsi untuk menangani semua jenis layanan
async function handleServiceAction(ctx, action) {
  let keyboard;
  if (action === 'create') {
    keyboard = [
      [{ text: '🍏 Create SSH', callback_data: 'create_ssh' }],      
      [{ text: '🍏 Create Vmess', callback_data: 'create_vmess' }],
      [{ text: '🍏 Create Vless', callback_data: 'create_vless' }],
      [{ text: '🍏 Create Trojan', callback_data: 'create_trojan' }],
      [{ text: '🍏 Create Shadowsocks', callback_data: 'create_shadowsocks' }],
      [{ text: '🔙 Kembali', callback_data: 'send_main_menu' }]
    ];
  } else if (action === 'delete') {
    keyboard = [
      [{ text: '🍎 Delete SSH', callback_data: 'delete_ssh' }],      
      [{ text: '🍎 Delete Vmess', callback_data: 'delete_vmess' }],
      [{ text: '🍎 Delete Vless', callback_data: 'delete_vless' }],
      [{ text: '🍎 Delete Trojan', callback_data: 'delete_trojan' }],
      [{ text: '🍎 Delete Shadowsocks', callback_data: 'delete_shadowsocks' }],
      [{ text: '🔙 Kembali', callback_data: 'send_main_menu' }]
    ];
  } else if (action === 'renew') {
    keyboard = [
      [{ text: '🍊 Renew SSH', callback_data: 'renew_ssh' }],      
      [{ text: '🍊 Renew Vmess', callback_data: 'renew_vmess' }],
      [{ text: '🍊 Renew Vless', callback_data: 'renew_vless' }],
      [{ text: '🍊 Renew Trojan', callback_data: 'renew_trojan' }],
      [{ text: '🍊 Renew Shadowsocks', callback_data: 'renew_shadowsocks' }],
      [{ text: '🔙 Kembali', callback_data: 'send_main_menu' }]
    ];
  } else if (action === 'check') {
    keyboard = [
      [{ text: '🍌 Check SSH', callback_data: 'check_ssh' }],      
      [{ text: '🍌 Check Vmess', callback_data: 'check_vmess' }],
      [{ text: '🍌 Check Vless', callback_data: 'check_vless' }],
      [{ text: '🍌 Check Trojan', callback_data: 'check_trojan' }],
      [{ text: '🍌 Check Shadowsocks', callback_data: 'check_shadowsocks' }],
      [{ text: '🔙 Kembali', callback_data: 'send_main_menu' }]
    ];
  }

  try {
    await ctx.editMessageReplyMarkup({
      inline_keyboard: keyboard
    });
    console.log(`${action} service menu sent`);
  } catch (error) {
    if (error.response && error.response.error_code === 400) {
      // Jika pesan tidak dapat diedit, kirim pesan baru
      await ctx.reply(`Pilih jenis layanan yang ingin Anda ${action}:`, {
        reply_markup: {
          inline_keyboard: keyboard
        }
      });
      console.log(`${action} service menu sent as new message`);
    } else {
      console.error(`Error saat mengirim menu ${action}:`, error);
    }
  }
}

async function sendAdminMenu(ctx) {
  const adminKeyboard = [
    [{ text: '➕ Tambah Server', callback_data: 'addserver' }],
    [{ text: '❌ Hapus Server', callback_data: 'deleteserver' }],   
    [{ text: '📜 List Server', callback_data: 'listserver' }],     
    [{ text: '🗑️ Reset Server', callback_data: 'resetdb' }],
    [{ text: '🔙 Kembali', callback_data: 'send_main_menu' }]
  ];

  try {
    await ctx.editMessageReplyMarkup({
      inline_keyboard: adminKeyboard
    });
    console.log('Admin menu sent');
  } catch (error) {
    if (error.response && error.response.error_code === 400) {
      // Jika pesan tidak dapat diedit, kirim pesan baru
      await ctx.reply('Menu Admin:', {
        reply_markup: {
          inline_keyboard: adminKeyboard
        }
      });
      console.log('Admin menu sent as new message');
    } else {
      console.error('Error saat mengirim menu admin:', error);
    }
  }
}

bot.action('service_trial', async (ctx) => {
  const keyboard = [
    [{ text: '🍏 Trial SSH', callback_data: 'trial_ssh' }],
    [{ text: '🍏 Trial Vmess', callback_data: 'trial_vmess' }],
    [{ text: '🍏 Trial Vless', callback_data: 'trial_vless' }],
    [{ text: '🍏 Trial Trojan', callback_data: 'trial_trojan' }],
    [{ text: '🍏 Trial Shadowsocks', callback_data: 'trial_shadowsocks' }],
    [{ text: '🔙 Kembali', callback_data: 'send_main_menu' }]
  ];
  try {
    await ctx.editMessageReplyMarkup({ inline_keyboard: keyboard });
  } catch (err) {
    // fallback kirim baru
    await ctx.reply('Pilih jenis trial:', {
      reply_markup: { inline_keyboard: keyboard }
    });
  }
});

// Reuse startSelectServer untuk daftar server — panggil dengan action 'trial'
bot.action('trial_vmess', async (ctx) => { await startSelectServer(ctx, 'trial', 'vmess'); });
bot.action('trial_vless', async (ctx) => { await startSelectServer(ctx, 'trial', 'vless'); });
bot.action('trial_trojan', async (ctx) => { await startSelectServer(ctx, 'trial', 'trojan'); });
bot.action('trial_shadowsocks', async (ctx) => { await startSelectServer(ctx, 'trial', 'shadowsocks'); });
bot.action('trial_ssh', async (ctx) => { await startSelectServer(ctx, 'trial', 'ssh'); });

// Action handlers untuk semua jenis layanan
bot.action('service_create', async (ctx) => {
  await handleServiceAction(ctx, 'create');
});

bot.action('service_delete', async (ctx) => {
  await handleServiceAction(ctx, 'delete');
});

bot.action('service_renew', async (ctx) => {
  await handleServiceAction(ctx, 'renew');
});

bot.action('service_check', async (ctx) => {
  await handleServiceAction(ctx, 'check');
});

// Action handler untuk kembali ke menu utama
bot.action('send_main_menu', async (ctx) => {
  await sendMainMenu(ctx);
});

// Action handlers for creating accounts
bot.action('create_vmess', async (ctx) => {
  await startSelectServer(ctx, 'create', 'vmess');
});

bot.action('create_vless', async (ctx) => {
  await startSelectServer(ctx, 'create', 'vless');
});

bot.action('create_trojan', async (ctx) => {
  await startSelectServer(ctx, 'create', 'trojan');
});

bot.action('create_shadowsocks', async (ctx) => {
  await startSelectServer(ctx, 'create', 'shadowsocks');
});

bot.action('create_ssh', async (ctx) => {
  await startSelectServer(ctx, 'create', 'ssh');
});

// Action handlers for deleting accounts
bot.action('delete_vmess', async (ctx) => {
  await startSelectServer(ctx, 'delete', 'vmess');
});

bot.action('delete_vless', async (ctx) => {
  await startSelectServer(ctx, 'delete', 'vless');
});

bot.action('delete_trojan', async (ctx) => {
  await startSelectServer(ctx, 'delete', 'trojan');
});

bot.action('delete_shadowsocks', async (ctx) => {
  await startSelectServer(ctx, 'delete', 'shadowsocks');
});

bot.action('delete_ssh', async (ctx) => {
  await startSelectServer(ctx, 'delete', 'ssh');
});

// Action handlers for renewing accounts
bot.action('renew_vmess', async (ctx) => {
  await startSelectServer(ctx, 'renew', 'vmess');
});

bot.action('renew_vless', async (ctx) => {
  await startSelectServer(ctx, 'renew', 'vless');
});

bot.action('renew_trojan', async (ctx) => {
  await startSelectServer(ctx, 'renew', 'trojan');
});

bot.action('renew_shadowsocks', async (ctx) => {
  await startSelectServer(ctx, 'renew', 'shadowsocks');
});

bot.action('renew_ssh', async (ctx) => {
  await startSelectServer(ctx, 'renew', 'ssh');
});
// Action handlers for checking accounts
bot.action('check_vmess', async (ctx) => {
  await startSelectServer(ctx, 'check', 'vmess');
});

bot.action('check_vless', async (ctx) => {
  await startSelectServer(ctx, 'check', 'vless');
});

bot.action('check_trojan', async (ctx) => {
  await startSelectServer(ctx, 'check', 'trojan');
});

bot.action('check_shadowsocks', async (ctx) => {
  await startSelectServer(ctx, 'check', 'shadowsocks');
});

bot.action('check_ssh', async (ctx) => {
  await startSelectServer(ctx, 'check', 'ssh');
});
// --- START: Trial via API (ganti handler trial lama) ---
const http = require('http');
const https = require('https');

function httpGetJson(url, timeout = 10_000) {
  return new Promise((resolve, reject) => {
    try {
      const lib = url.startsWith('https://') ? https : http;
      const req = lib.get(url, { timeout }, (res) => {
        let data = '';
        res.on('data', chunk => data += chunk);
        res.on('end', () => {
          // try parse JSON (clean trailing commas if any)
          try {
            const cleaned = data.replace(/,\s*}/g, '}').replace(/,\s*]/g, ']');
            const j = JSON.parse(cleaned);
            resolve(j);
          } catch (err) {
            // not JSON or parse error -> return raw
            resolve({ __raw: data, __parseError: err.message });
          }
        });
      });
      req.on('error', (err) => reject(err));
      req.on('timeout', () => { req.destroy(); reject(new Error('timeout')); });
    } catch (err) {
      reject(err);
    }
  });
}

// === Trial handler (FULL BOX untuk semua protokol, sesuai output API scripts) ===
const crypto = require('crypto'); // pastikan tersedia di context bot

bot.action(/(trial)_username_(vmess|vless|trojan|shadowsocks|ssh)_(.+)/, async (ctx) => {
  const action = ctx.match[1];
  const type = ctx.match[2];
  const serverId = ctx.match[3];
  userState[ctx.chat.id] = { step: 'username_' + action + '_' + type, serverId, type, action };

  await ctx.answerCbQuery().catch(()=>{});
  await ctx.reply('Menjalankan trial via API server...');

  const trunc = (s, n = 2500) => (typeof s === 'string' && s.length > n ? s.slice(0, n) + '...(truncated)' : s);

  // Helper: ambil field dari d.ports atau fallback
  const Pget = (d, k, fallback) => {
    if (!d) return typeof fallback !== 'undefined' ? fallback : '-';
    if (d.ports && (d.ports[k] || d.ports[k.toLowerCase()])) return d.ports[k] || d.ports[k.toLowerCase()];
    return typeof fallback !== 'undefined' ? fallback : '-';
  };

  function formatMessage(d = {}, proto = 'unknown', domain = 'unknown') {
    const expire = d.expiration || d.exp || '-';
    let msg = '🎉 *Trial Berhasil Dibuat!*' + '\n';
    msg += '🖥️ *Server:* `' + domain + '`' + '\n';
    msg += '⏳ *Expired:* `' + expire + '`' + '\n\n';

    // -------------------
    // SSH
    // -------------------
    if (proto === 'ssh') {
      const host = domain;
      const user = d.username || '-';
      const pass = d.password || d.pass || '-';
      const openssh = Pget(d, 'openssh', '22');
      const tls = Pget(d, 'ssl_tls', Pget(d, 'ssl', '443'));
      const http = Pget(d, 'http', '80');
      const udpssh = Pget(d, 'udp_ssh', '1-65535');
      const dns = Pget(d, 'dns', '443, 53, 22');
      const dropbear = Pget(d, 'dropbear', '443, 109');
      const ssh_ws = Pget(d, 'ssh_ws', '80');
      const ssh_ssl_ws = Pget(d, 'ssh_ssl_ws', '443');
      const ovpn_ssl = Pget(d, 'ovpn_ssl', '443');
      const ovpn_tcp = Pget(d, 'ovpn_tcp', '1194');
      const ovpn_udp = Pget(d, 'ovpn_udp', '2200');
      const badvpn = Pget(d, 'badvpn', '7100,7200,7300');
      const ipLimit = d.ip_limit || d.iplimit || '-';
      const ns = d.ns_domain || '-';
      const pubkey = d.public_key && d.public_key !== 'Public key not available' ? d.public_key : 'Public key not found';

      msg += '┌─────────────────────\n';
      msg += '│ *Username* : `' + user + '`\n';
      msg += '│ *Password* : `' + pass + '`\n';
      msg += '└─────────────────────\n';
      msg += '┌─────────────────────\n';
      msg += '│ *Domain*      : `' + host + '`\n';
      msg += '│ *NS*          : `' + ns + '`\n';
      msg += '│ *Port TLS*    : `' + tls + '`\n';
      msg += '│ *Port HTTP*   : `' + http + '`\n';
      msg += '│ *OpenSSH*     : `' + openssh + '`\n';
      msg += '│ *UdpSSH*      : `' + udpssh + '`\n';
      msg += '│ *DNS*         : `' + dns + '`\n';
      msg += '│ *Dropbear*    : `' + dropbear + '`\n';
      msg += '│ *SSH WS*      : `' + ssh_ws + '`\n';
      msg += '│ *SSH SSL WS*  : `' + ssh_ssl_ws + '`\n';
      msg += '│ *SSL/TLS*     : `' + tls + '`\n';
      msg += '│ *OVPN SSL*    : `' + ovpn_ssl + '`\n';
      msg += '│ *OVPN TCP*    : `' + ovpn_tcp + '`\n';
      msg += '│ *OVPN UDP*    : `' + ovpn_udp + '`\n';
      msg += '│ *BadVPN UDP*  : `' + badvpn + '`\n';
      msg += '└─────────────────────\n\n';

      msg += '🔒 *PUBKEY*\n';
      msg += '```\n' + pubkey + '\n```\n\n';

      msg += '🔗 *Link dan Payload*\n';
      msg += '───────────────────────\n';
      const payload = d.wss_payload || d.payload || d.ws_payload || '';
      if (payload) {
        msg += 'WSS Payload:\n```\n' + trunc(payload, 5000) + '\n```\n';
      } else {
        msg += 'WSS Payload: `-`\n';
      }
      if (d.openvpn_link) msg += 'OpenVPN Link     : ' + d.openvpn_link + '\n';
      if (d.save_link) msg += 'Save Account Link: `' + d.save_link + '`\n';

      msg += '───────────────────────\n';
      msg += '┌─────────────────────\n';
      msg += '│ Expires : `' + expire + '`\n';
      msg += '│ IP Limit: `' + (d.ip_limit || d.iplimit || '-') + '`\n';
      msg += '└─────────────────────\n\n';
      msg += '✨ Selamat menggunakan layanan kami! ✨';
      return msg;
    }

    // -------------------
    // VMESS (updated: show username + uuid)
    // -------------------
    if (proto === 'vmess') {
      const uuid = d.uuid || '-';
      const user = d.username || uuid || '-';
      const alter = d.alter_id || d.alterid || '-';
      const domainShow = d.domain || domain;

      msg += '┌─────────────────────\n';
      msg += '│ *Akun VMESS*\n';
      msg += '│ User : `' + user + '`\n';
      msg += '│ UUID : `' + uuid + '`\n';
      msg += '│ Domain: `' + domainShow + '`\n';
      msg += '└─────────────────────\n\n';

      if (d.link_tls)  msg += '🔐 *VMESS TLS*\n```\n' + trunc(d.link_tls, 5000) + '\n```\n';
      if (d.link_ntls) msg += '🔓 *VMESS Non-TLS*\n```\n' + trunc(d.link_ntls, 5000) + '\n```\n';
      if (d.link_grpc) msg += '📡 *VMESS gRPC*\n```\n' + trunc(d.link_grpc, 5000) + '\n```\n';

      // ports if present
      const portTLS = d.port_tls || d.port || '-';
      const portHTTP = d.port_http || '-';
      msg += '┌─────────────────────\n';
      msg += '│ *Port Detail* \n';
      msg += '│ TLS : `' + portTLS + '`\n';
      msg += '│ HTTP: `' + portHTTP + '`\n';
      msg += '└─────────────────────\n\n';

      msg += '───────────────────────\n';
      msg += '┌─────────────────────\n';
      msg += '│ Expires : `' + expire + '`\n';
      msg += '└─────────────────────\n\n';
      return msg;
    }

    // -------------------
    // VLESS (match script)
    // -------------------
    if (proto === 'vless') {
      const uuid = d.uuid || '-';
      const user = d.username || '-';
      const ns = d.ns_domain || '-';
      const city = d.city || '-';
      const domainShow = d.domain || domain;

      const portTLS = d.port_tls || '443';
      const portHTTP = d.port_http || '80, 8080';
      const dnsPort = d.dns_port || '443, 53';
      const grpcPort = d.grpc_port || '443';
      const path = d.path || '/';
      const svc = d.service_name || '-';
      const pubkey = d.public_key || 'Public key not found';

      msg += '┌─────────────────────\n';
      msg += '│ *Akun VLESS*\n';
      msg += '│ User   : `' + user + '`\n';
      msg += '│ UUID   : `' + uuid + '`\n';
      msg += '│ Domain : `' + domainShow + '`\n';
      msg += '│ NS     : `' + ns + '`\n';
      msg += '│ City   : `' + city + '`\n';
      msg += '└─────────────────────\n\n';

      // port block
      msg += '┌─────────────────────\n';
      msg += '│ *Port Detail*\n';
      msg += '│ TLS  : `' + portTLS + '`\n';
      msg += '│ HTTP : `' + portHTTP + '`\n';
      msg += '│ DNS  : `' + dnsPort + '`\n';
      msg += '│ gRPC : `' + grpcPort + '`\n';
      msg += '│ Path : `' + path + '`\n';
      msg += '│ Svc  : `' + svc + '`\n';
      msg += '└─────────────────────\n\n';

      // public key
      msg += '🔒 *PUBKEY*\n';
      msg += '```\n' + pubkey + '\n```\n\n';

      // links
      if (d.link_tls)  msg += '🔐 *VLESS TLS*\n```\n' + trunc(d.link_tls, 5000) + '\n```\n';
      if (d.link_ntls) msg += '🔓 *VLESS Non-TLS*\n```\n' + trunc(d.link_ntls, 5000) + '\n```\n';
      if (d.link_grpc) msg += '📡 *VLESS gRPC*\n```\n' + trunc(d.link_grpc, 5000) + '\n```\n';

      msg += '───────────────────────\n';
      msg += '┌─────────────────────\n';
      msg += '│ Expires : `' + expire + '`\n';
      msg += '└─────────────────────\n\n';
      return msg;
    }

    // -------------------
    // TROJAN (updated: show username and use uuid as "pass" if provided)
    // -------------------
    if (proto === 'trojan') {
      const uuid = d.uuid || '-';
      const user = d.username || '-';
      // show uuid instead of password if available
      const passOrUuid = (uuid && uuid !== '-') ? uuid : (d.password || d.pass || '-');
      const domainShow = d.domain || domain;

      msg += '┌─────────────────────\n';
      msg += '│ *Akun Trojan*\n';
      if (user && user !== '-') msg += '│ User   : `' + user + '`\n';
      msg += '│ Domain : `' + domainShow + '`\n';
      msg += '│ UUID   : `' + passOrUuid + '`\n';
      msg += '└─────────────────────\n\n';

      if (d.link_tls)  msg += '🔐 *Trojan TLS*\n```\n' + trunc(d.link_tls, 5000) + '\n```\n';
      if (d.link_grpc) msg += '📡 *Trojan gRPC*\n```\n' + trunc(d.link_grpc, 5000) + '\n```\n';

      msg += '───────────────────────\n';
      msg += '┌─────────────────────\n';
      msg += '│ Expires : `' + expire + '`\n';
      msg += '└─────────────────────\n\n';
      return msg;
    }

    // -------------------
    // SHADOWSOCKS (match script)
    // -------------------
    if (proto === 'shadowsocks' || proto === 'ss') {
      const method = d.method || '-';
      const pass = d.password || '-';

      msg += '┌─────────────────────\n';
      msg += '│ *Akun Shadowsocks*\n';
      msg += '│ Method   : `' + method + '`\n';
      msg += '│ Password : `' + pass + '`\n';
      msg += '└─────────────────────\n\n';

      if (d.link_ws)   msg += '🔗 *SS WS Link*\n```\n' + trunc(d.link_ws, 5000) + '\n```\n';
      if (d.link_grpc) msg += '📡 *SS gRPC Link*\n```\n' + trunc(d.link_grpc, 5000) + '\n```\n';

      msg += '───────────────────────\n';
      msg += '┌─────────────────────\n';
      msg += '│ Expires : `' + expire + '`\n';
      msg += '└─────────────────────\n\n';
      return msg;
    }

    // fallback: show keys count
    msg += '*Data fields:* `' + Object.keys(d || {}).length + '`';
    return msg;
  }

  // fetch server from DB and call API
  db.get('SELECT * FROM Server WHERE id = ?', [serverId], async (err, server) => {
    if (err || !server) {
      await ctx.reply('❌ Gagal: server tidak ditemukan.');
      delete userState[ctx.chat.id];
      return;
    }

    const domain = server.domain;
    const auth = server.auth || '';
    if (!auth) {
      await ctx.reply('❌ Auth server kosong.');
      delete userState[ctx.chat.id];
      return;
    }

    const routeMap = {
      ssh: 'trialssh',
      vmess: 'trialvmess',
      vless: 'trialvless',
      trojan: 'trialtrojan',
      shadowsocks: 'trialshadowsocks'
    };
    const route = routeMap[type];
    const port = server.port || 5888;
    const protocol = port == 443 ? 'https' : 'http';

    // If vmess or trojan: generate a username and pass it to API so server can create same username
    let generatedUsername = null;
    let url = protocol + '://' + domain + ':' + port + '/' + route + '?auth=' + encodeURIComponent(auth);

    if (type === 'vmess' || type === 'trojan') {
      // generate username like scripts: trial + 4 hex chars
      generatedUsername = 'trial' + crypto.randomBytes(2).toString('hex').slice(0,4);
      url += '&username=' + encodeURIComponent(generatedUsername);
    }

    try {
      const json = await httpGetJson(url, 12000);
      if (!json || json.status !== 'success') {
        const detail = (json && (json.error || json.message)) || JSON.stringify(json || {});
        await ctx.reply('❌ Trial gagal. Detail: ' + trunc(detail));
        return;
      }

      const data = json.data || json;

      // ensure username present in data for consistent display (if we generated and server didn't include)
      if (generatedUsername && (!data.username || data.username === '')) {
        data.username = generatedUsername;
      }

      // For trojan: if server doesn't return uuid but returns password, keep as-is; formatMessage handles fallback
      const message = formatMessage(data, type, domain);
      await ctx.reply(message, { parse_mode: 'Markdown' });

    } catch (e) {
      await ctx.reply('❌ Error komunikasi API: ' + trunc(e.message, 800));
    } finally {
      delete userState[ctx.chat.id];
    }
  });
});
// --- END: Trial via API ---
// Function to start selecting a server
async function startSelectServer(ctx, action, type) {
  try {
    console.log(`Memulai proses ${action} untuk ${type}`);
    
    db.all('SELECT * FROM Server', [], (err, servers) => {
      if (err) {
        console.error('Error fetching servers:', err.message);
        return ctx.reply('⚠️ PERHATIAN! Tidak ada server yang tersedia saat ini. Coba lagi nanti!');
      }

      if (servers.length === 0) {
        console.log('Tidak ada server yang tersedia');
        return ctx.reply('⚠️ PERHATIAN! Tidak ada server yang tersedia saat ini. Coba lagi nanti!');
      }

      const keyboard = servers.map(server => {
        return [{ text: server.domain, callback_data: `${action}_username_${type}_${server.id}` }];
      });
      keyboard.push([{ text: '🔙 Kembali ke Menu Utama', callback_data: 'send_main_menu' }]);

      ctx.answerCbQuery();
      ctx.deleteMessage();
      ctx.reply('Pilih server:', {
        reply_markup: {
          inline_keyboard: keyboard
        }
      });

      // Menyimpan state pengguna
      userState[ctx.chat.id] = { step: `${action}_username_${type}` };
    });
  } catch (error) {
    console.error(`Error saat memulai proses ${action} untuk ${type}:`, error);
    await ctx.reply(`❌ GAGAL! Terjadi kesalahan saat memproses permintaan Anda. Silakan coba lagi nanti.`);
  }
}
// Handle server selection
bot.action(/(create|delete|renew|check)_username_(vmess|vless|trojan|shadowsocks|ssh)_(.+)/, async (ctx) => {
  const action = ctx.match[1];
  const type = ctx.match[2];
  const serverId = ctx.match[3];
  userState[ctx.chat.id] = { step: `username_${action}_${type}`, serverId, type, action };
  if (action === 'check') {
    let msg;
    if (type === 'vmess') {
      msg = await checkvmess(serverId);
    } else if (type === 'vless') {
      msg = await checkvless(serverId);
    } else if (type === 'trojan') {
      msg = await checktrojan(serverId);
    } else if (type === 'shadowsocks') {
      msg = await checkshadowsocks(serverId);
    } else if (type === 'ssh') {
      msg = await checkssh(serverId);
    }
    await ctx.reply(msg, { parse_mode: 'Markdown' });
    delete userState[ctx.chat.id];
  } else {
    await ctx.reply('👤 Masukkan username:');
  }
});

// Handle text input for various steps
bot.on('text', async (ctx) => {
  const state = userState[ctx.chat.id];

  if (!state) return; // Jika tidak ada state, abaikan pesan

  if (state.step.startsWith('username_')) {
    state.username = ctx.message.text;
    const { username, serverId, type, action } = state;
    let msg;
    if (action === 'create') {
      if (type === 'ssh') {
        state.step = `password_${state.action}_${state.type}`;
        await ctx.reply('🔑 Masukkan password:');
      } else {
        state.step = `exp_${state.action}_${state.type}`;
        await ctx.reply('⏳ Masukkan masa aktif (hari):');
      }
    } else if (action === 'renew') {
      state.step = `exp_${state.action}_${state.type}`;
      await ctx.reply('⏳ Masukkan masa aktif (hari):');
    } else if (action === 'delete') {
      if (type === 'vmess') {
        msg = await deletevmess(username, serverId);
      } else if (type === 'vless') {
        msg = await deletevless(username, serverId);
      } else if (type === 'trojan') {
        msg = await deletetrojan(username, serverId);
      } else if (type === 'shadowsocks') {
        msg = await deleteshadowsocks(username, serverId);
      } else if (type === 'ssh') {
        msg = await deletessh(username, serverId);
      }
      await ctx.reply(msg, { parse_mode: 'Markdown' });
      delete userState[ctx.chat.id];
    }
  } else if (state.step.startsWith('password_')) {
    state.password = ctx.message.text;
    state.step = `exp_${state.action}_${state.type}`;
    await ctx.reply('⏳ Masukkan masa aktif (hari):');
  } else if (state.step.startsWith('exp_')) {
    if (!/^\d+$/.test(ctx.message.text)) {
      await ctx.reply('❌ PERHATIAN! Masukkan HANYA ANGKA untuk masa berlaku akun!');
      return;
    }
    state.exp = ctx.message.text;
    if (state.type === 'ssh') {
      state.step = `limitip_${state.action}_${state.type}`;
      await ctx.reply('🔢 Masukkan limit IP:');
    } else {
      state.step = `quota_${state.action}_${state.type}`;
      await ctx.reply('📊 Masukkan quota (GB):');
    }
  } else if (state.step.startsWith('quota_')) {
    if (!/^\d+$/.test(ctx.message.text)) {
      await ctx.reply('❌ PERHATIAN! Masukkan HANYA ANGKA untuk quota!');
      return;
    }
    state.quota = ctx.message.text;
    state.step = `limitip_${state.action}_${state.type}`;
    await ctx.reply('🔢 Masukkan limit IP:');
  } else if (state.step.startsWith('limitip_')) {
    if (!/^\d+$/.test(ctx.message.text)) {
      await ctx.reply('❌ PERHATIAN! Masukkan HANYA ANGKA untuk limit IP!');
      return;
    }
    state.limitip = ctx.message.text;
    const { username, password, exp, quota, limitip, serverId, type, action } = state;
    let msg;
    if (action === 'create') {
      if (type === 'vmess') {
        msg = await createvmess(username, exp, quota, limitip, serverId);
      } else if (type === 'vless') {
        msg = await createvless(username, exp, quota, limitip, serverId);
      } else if (type === 'trojan') {
        msg = await createtrojan(username, exp, quota, limitip, serverId);
      } else if (type === 'shadowsocks') {
        msg = await createshadowsocks(username, exp, quota, limitip, serverId);
      } else if (type === 'ssh') {
        msg = await createssh(username, password, exp, limitip, serverId);
      }
    } else if (action === 'renew') {
      if (type === 'vmess') {
        msg = await renewvmess(username, exp, quota, limitip, serverId);
      } else if (type === 'vless') {
        msg = await renewvless(username, exp, quota, limitip, serverId);
      } else if (type === 'trojan') {
        msg = await renewtrojan(username, exp, quota, limitip, serverId);
      } else if (type === 'shadowsocks') {
        msg = await renewshadowsocks(username, exp, quota, limitip, serverId);
      } else if (type === 'ssh') {
        msg = await renewssh(username, exp, limitip, serverId);
      }
    }
    await ctx.reply(msg, { parse_mode: 'Markdown' });
    delete userState[ctx.chat.id];
  } else if (state.step === 'addserver') {
    const domain = ctx.message.text.trim();
    if (!domain) {
      await ctx.reply('⚠️ Domain tidak boleh kosong. Silakan masukkan domain server yang valid.');
      return;
    }

    state.step = 'addserver_auth';
    state.domain = domain;
    await ctx.reply('🔑 Silakan masukkan auth server:');
  } else if (state.step === 'addserver_auth') {
    const auth = ctx.message.text.trim();
    if (!auth) {
      await ctx.reply('⚠️ Auth tidak boleh kosong. Silakan masukkan auth server yang valid.');
      return;
    }

    const { domain } = state;

    try {
      db.run('INSERT INTO Server (domain, auth) VALUES (?, ?)', [domain, auth], function(err) {
        if (err) {
          console.error('Error saat menambahkan server:', err.message);
          ctx.reply('❌ Terjadi kesalahan saat menambahkan server baru.');
        } else {
          ctx.reply(`✅ Server baru dengan domain ${domain} telah berhasil ditambahkan.`);
        }
      });
    } catch (error) {
      console.error('Error saat menambahkan server:', error);
      await ctx.reply('❌ Terjadi kesalahan saat menambahkan server baru.');
    }
    delete userState[ctx.chat.id];
  }
});
//ADMIN
bot.action('deleteserver', async (ctx) => {
  try {
    console.log('Delete server process started');
    await ctx.answerCbQuery();
    
    db.all('SELECT * FROM Server', [], (err, servers) => {
      if (err) {
        console.error('Error fetching servers:', err.message);
        return ctx.reply('⚠️ PERHATIAN! Terjadi kesalahan saat mengambil daftar server.');
      }

      if (servers.length === 0) {
        console.log('Tidak ada server yang tersedia');
        return ctx.reply('⚠️ PERHATIAN! Tidak ada server yang tersedia saat ini.');
      }

      const keyboard = servers.map(server => {
        return [{ text: server.domain, callback_data: `confirm_delete_server_${server.id}` }];
      });
      keyboard.push([{ text: '🔙 Kembali ke Menu Utama', callback_data: 'kembali_ke_menu' }]);

      ctx.reply('Pilih server yang ingin dihapus:', {
        reply_markup: {
          inline_keyboard: keyboard
        }
      });
    });
  } catch (error) {
    console.error('Kesalahan saat memulai proses hapus server:', error);
    await ctx.reply('❌ GAGAL! Terjadi kesalahan saat memproses permintaan Anda. Silakan coba lagi nanti.');
  }
});

bot.action(/confirm_delete_server_(\d+)/, async (ctx) => {
  try {
    db.run('DELETE FROM Server WHERE id = ?', [ctx.match[1]], function(err) {
      if (err) {
        console.error('Error deleting server:', err.message);
        return ctx.reply('⚠️ PERHATIAN! Terjadi kesalahan saat menghapus server.');
      }

      if (this.changes === 0) {
        console.log('Server tidak ditemukan');
        return ctx.reply('⚠️ PERHATIAN! Server tidak ditemukan.');
      }

      console.log(`Server dengan ID ${ctx.match[1]} berhasil dihapus`);
      ctx.reply('✅ Server berhasil dihapus.');
    });
  } catch (error) {
    console.error('Kesalahan saat menghapus server:', error);
    await ctx.reply('❌ GAGAL! Terjadi kesalahan saat memproses permintaan Anda. Silakan coba lagi nanti.');
  }
});

bot.action('addserver', async (ctx) => {
  try {
    console.log('Add server process started');
    await ctx.answerCbQuery();
    await ctx.reply('🌐 Silakan masukkan domain/ip server:');
    userState[ctx.chat.id] = { step: 'addserver' };
  } catch (error) {
    console.error('Kesalahan saat memulai proses tambah server:', error);
    await ctx.reply('❌ GAGAL! Terjadi kesalahan saat memproses permintaan Anda. Silakan coba lagi nanti.');
  }
});

bot.action('listserver', async (ctx) => {
  try {
    console.log('List server process started');
    await ctx.answerCbQuery();
    
    db.all('SELECT * FROM Server', [], (err, servers) => {
      if (err) {
        console.error('Error fetching servers:', err.message);
        return ctx.reply('⚠️ PERHATIAN! Terjadi kesalahan saat mengambil daftar server.');
      }

      if (servers.length === 0) {
        console.log('Tidak ada server yang tersedia');
        return ctx.reply('⚠️ PERHATIAN! Tidak ada server yang tersedia saat ini.');
      }

      let serverList = '📜 *Daftar Server* 📜\n\n';
      servers.forEach((server, index) => {
        serverList += `${index + 1}. ${server.domain}\n`;
      });

      ctx.reply(serverList, { parse_mode: 'Markdown' });
    });
  } catch (error) {
    console.error('Kesalahan saat mengambil daftar server:', error);
    await ctx.reply('❌ GAGAL! Terjadi kesalahan saat memproses permintaan Anda. Silakan coba lagi nanti.');
  }
});

bot.action('resetdb', async (ctx) => {
  try {
    await ctx.answerCbQuery();
    db.run('DELETE FROM Server', (err) => {
      if (err) {
        console.error('Error saat mereset tabel Server:', err.message);
        ctx.reply('❗️ PERHATIAN! Terjadi KESALAHAN SERIUS saat mereset database. Harap segera hubungi administrator!');
      }
    });
    await ctx.reply('🚨 PERHATIAN! Database telah DIRESET SEPENUHNYA. Semua server telah DIHAPUS TOTAL.');
  } catch (error) {
    console.error('Error saat mereset database:', error);
    await ctx.reply('❗️ PERHATIAN! Terjadi KESALAHAN SERIUS saat mereset database. Harap segera hubungi administrator!');
  }
});

// Mulai bot
bot.launch().then(() => {
  console.log('Bot telah dimulai');
}).catch((error) => {
  console.error('Error saat memulai bot:', error);
});