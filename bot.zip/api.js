const os = require('os');
const { exec, execSync, spawn } = require('child_process');
const express = require('express');
const path = require('path');
const fs = require('fs');

const app = express();

// Middleware untuk memeriksa kata sandi
const checkPassword = (req, res, next) => {
  const { auth } = req.query;
  const correctPassword = fs.readFileSync('/root/.key', 'utf8').trim(); // Membaca kata sandi dari /root/.key
  
  if (auth !== correctPassword) {
    return res.status(401).send('<html><body><h1 style="text-align: center;">Akses Ditolak</h1><p style="text-align: center;">Anda tidak memiliki izin untuk mengakses halaman ini.</p></body></html>');
  }
  
  next();
};

// Terapkan middleware checkPassword ke semua rute
app.use(checkPassword);

// Create ssh user
app.get("/createssh", (req, res) => {
  const { user, password, exp, iplimit } = req.query;
  if (!user || !password || !exp || !iplimit) {
    return res.status(400).json({ error: 'Username, expiry, iplimit, dan password diperlukan' });
  }
  
  console.log(`Menerima permintaan untuk membuat akun SSH dengan user: ${user}, exp: ${exp}, iplimit: ${iplimit}, password: ${password}`);
  
  const child = spawn("/bin/bash", ["-c", `apicreate ssh ${user} ${password} ${exp} ${iplimit}`], {
    stdio: ['pipe', 'pipe', 'pipe']
  });
  
  child.stdin.end();
  let output = '';
  child.stdout.on('data', (data) => {
    output += data.toString();
  });
  
  child.stderr.on('data', (data) => {
    console.error(`Kesalahan: ${data}`);
    output += data.toString();
  });
  
  child.on('close', (code) => {
    if (code !== 0) {
      console.log(`Proses pembuatan akun SSH gagal dengan kode: ${code}`);
      return res.status(500).json({ error: 'Terjadi kesalahan saat membuat akun', detail: output });
    }
    console.log(`Akun SSH berhasil dibuat untuk user: ${user}`);
    
    try {
      const jsonResponse = JSON.parse(output);
      if (jsonResponse.status === "success") {
        res.json({
          status: "success",
          message: "SSH account successfully created",
          data: {
            username: jsonResponse.data.username,
            password: jsonResponse.data.password,
            expired: jsonResponse.data.expired,            
            ip_limit: jsonResponse.data.ip_limit,
            domain: jsonResponse.data.domain,
            ns_domain: jsonResponse.data.ns_domain,
            city: jsonResponse.data.city,
            pubkey: jsonResponse.data.pubkey
          }
        });
      } else {
        res.status(500).json({ error: "Gagal membuat akun SSH", detail: jsonResponse.message });
      }
    } catch (err) {
      console.error(`Kesalahan parsing JSON: ${err}`);
      res.status(500).json({ error: "Terjadi kesalahan saat memproses hasil", detail: err.message });
    }
  });
});

// Create vmess user
app.get("/createvmess", (req, res) => {
  const { user, exp, quota, iplimit } = req.query;
  if (!user || !exp || !quota || !iplimit) {
    return res.status(400).json({ error: 'Username, expiry, quota, dan iplimit diperlukan' });
  }
  
  console.log(`Menerima permintaan untuk membuat akun VMess dengan user: ${user}, exp: ${exp}, quota: ${quota}, iplimit: ${iplimit}`);
  
  const child = spawn("/bin/bash", ["-c", `apicreate vmess ${user} ${exp} ${quota} ${iplimit}`], {
    stdio: ['pipe', 'pipe', 'pipe']
  });
  
  child.stdin.end();
  let output = '';
  child.stdout.on('data', (data) => {
    output += data.toString();
  });
  
  child.stderr.on('data', (data) => {
    console.error(`Kesalahan: ${data}`);
    output += data.toString();
  });
  
  child.on('close', (code) => {
    if (code !== 0) {
      console.log(`Proses pembuatan akun VMess gagal dengan kode: ${code}`);
      return res.status(500).json({ error: 'Terjadi kesalahan saat membuat akun', detail: output });
    }
    console.log(`Akun VMess berhasil dibuat untuk user: ${user}`);
    
    try {
      const jsonResponse = JSON.parse(output);
      if (jsonResponse.status === "success") {
        res.json({
          status: "success",
          message: "Vmess account successfully created",
          data: {
            username: jsonResponse.data.username,
            expired: jsonResponse.data.expired,
            uuid: jsonResponse.data.uuid,
            quota: jsonResponse.data.quota,
            ip_limit: jsonResponse.data.ip_limit,
            domain: jsonResponse.data.domain,
            ns_domain: jsonResponse.data.ns_domain,
            city: jsonResponse.data.city,
            pubkey: jsonResponse.data.pubkey,
            vmess_tls_link: jsonResponse.data.vmess_tls_link,
            vmess_nontls_link: jsonResponse.data.vmess_nontls_link,
            vmess_grpc_link: jsonResponse.data.vmess_grpc_link
          }
        });
      } else {
        res.status(500).json({ error: 'Terjadi kesalahan saat membuat akun', detail: jsonResponse.message });
      }
    } catch (error) {
      console.error('Error parsing JSON:', error);
      res.status(500).json({ error: 'Terjadi kesalahan saat memproses output JSON' });
    }
  });
});


// Create vless user
app.get("/createvless", (req, res) => {
  const { user, exp, quota, iplimit } = req.query;
  if (!user || !exp || !quota || !iplimit) {
    return res.status(400).json({ error: 'Username, expiry, quota, dan iplimit diperlukan' });
  }
  
  console.log(`Menerima permintaan untuk membuat akun VLESS dengan user: ${user}, exp: ${exp}, quota: ${quota}, iplimit: ${iplimit}`);
  
  const child = spawn("/bin/bash", ["-c", `apicreate vless ${user} ${exp} ${quota} ${iplimit}`], {
    stdio: ['pipe', 'pipe', 'pipe']
  });
  
  child.stdin.end();
  let output = '';
  child.stdout.on('data', (data) => {
    output += data.toString();
  });
  
  child.stderr.on('data', (data) => {
    console.error(`Kesalahan: ${data}`);
    output += data.toString();
  });
  
  child.on('close', (code) => {
    if (code !== 0) {
      console.log(`Proses pembuatan akun VLESS gagal dengan kode: ${code}`);
      return res.status(500).json({ error: 'Terjadi kesalahan saat membuat akun', detail: output });
    }
    console.log(`Akun VLESS berhasil dibuat untuk user: ${user}`);
    
    try {
      const jsonResponse = JSON.parse(output);
      if (jsonResponse.status === "success") {
        res.json({
          status: "success",
          message: "VLESS account successfully created",
          data: {
            username: jsonResponse.data.username,
            expired: jsonResponse.data.expired,
            uuid: jsonResponse.data.uuid,
            quota: jsonResponse.data.quota,
            ip_limit: jsonResponse.data.ip_limit,
            domain: jsonResponse.data.domain,
            ns_domain: jsonResponse.data.ns_domain,
            city: jsonResponse.data.city,
            pubkey: jsonResponse.data.pubkey,
            vless_tls_link: jsonResponse.data.vless_tls_link,
            vless_nontls_link: jsonResponse.data.vless_nontls_link,
            vless_grpc_link: jsonResponse.data.vless_grpc_link
          }
        });
      } else {
        res.status(500).json({ error: 'Terjadi kesalahan saat membuat akun', detail: jsonResponse.message });
      }
    } catch (error) {
      console.error('Error parsing JSON:', error);
      res.status(500).json({ error: 'Terjadi kesalahan saat memproses output JSON' });
    }
  });
});

// Create trojan user
app.get("/createtrojan", (req, res) => {
  const { user, exp, quota, iplimit } = req.query;
  if (!user || !exp || !quota || !iplimit) {
    return res.status(400).json({ error: 'Username, expiry, quota, dan iplimit diperlukan' });
  }
  
  console.log(`Menerima permintaan untuk membuat akun Trojan dengan user: ${user}, exp: ${exp}, quota: ${quota}, iplimit: ${iplimit}`);
  
  const child = spawn("/bin/bash", ["-c", `apicreate trojan ${user} ${exp} ${quota} ${iplimit}`], {
    stdio: ['pipe', 'pipe', 'pipe']
  });
  
  child.stdin.end();
  let output = '';
  child.stdout.on('data', (data) => {
    output += data.toString();
  });
  
  child.stderr.on('data', (data) => {
    console.error(`Kesalahan: ${data}`);
    output += data.toString();
  });
  
  child.on('close', (code) => {
    if (code !== 0) {
      console.log(`Proses pembuatan akun Trojan gagal dengan kode: ${code}`);
      return res.status(500).json({ error: 'Terjadi kesalahan saat membuat akun', detail: output });
    }
    console.log(`Akun Trojan berhasil dibuat untuk user: ${user}`);
    
    try {
      const jsonResponse = JSON.parse(output);
      if (jsonResponse.status === "success") {
        res.json({
          status: "success",
          message: "Trojan account successfully created",
          data: {
            username: jsonResponse.data.username,
            expired: jsonResponse.data.expired,
            uuid: jsonResponse.data.uuid,
            quota: jsonResponse.data.quota,
            ip_limit: jsonResponse.data.ip_limit,
            domain: jsonResponse.data.domain,
            ns_domain: jsonResponse.data.ns_domain,
            city: jsonResponse.data.city,
            pubkey: jsonResponse.data.pubkey,
            trojan_tls_link: jsonResponse.data.trojan_tls_link,
            trojan_grpc_link: jsonResponse.data.trojan_grpc_link
          }
        });
      } else {
        res.status(500).json({ error: 'Terjadi kesalahan saat membuat akun', detail: jsonResponse.message });
      }
    } catch (error) {
      console.error('Error parsing JSON:', error);
      res.status(500).json({ error: 'Terjadi kesalahan saat memproses output JSON' });
    }
  });
});


// Create shadowsocks user
app.get("/createshadowsocks", (req, res) => {
  const { user, exp, quota, iplimit } = req.query;
  if (!user || !exp || !quota || !iplimit) {
    return res.status(400).json({ error: 'Username, expiry, quota, dan iplimit diperlukan' });
  }
  
  console.log(`Menerima permintaan untuk membuat akun Shadowsocks dengan user: ${user}, exp: ${exp}, quota: ${quota}, iplimit: ${iplimit}`);
  
  const child = spawn("/bin/bash", ["-c", `apicreate shadowsocks ${user} ${exp} ${quota} ${iplimit}`], {
    stdio: ['pipe', 'pipe', 'pipe']
  });
  
  child.stdin.end();
  let output = '';
  child.stdout.on('data', (data) => {
    output += data.toString();
  });
  
  child.stderr.on('data', (data) => {
    console.error(`Kesalahan: ${data}`);
    output += data.toString();
  });
  
  child.on('close', (code) => {
    if (code !== 0) {
      console.log(`Proses pembuatan akun Shadowsocks gagal dengan kode: ${code}`);
      return res.status(500).json({ error: 'Terjadi kesalahan saat membuat akun', detail: output });
    }
    console.log(`Akun Shadowsocks berhasil dibuat untuk user: ${user}`);
    
    try {
      const jsonResponse = JSON.parse(output);
      if (jsonResponse.status === "success") {
        res.json({
          status: "success",
          message: "Shadowsocks account successfully created",
          data: {
            username: jsonResponse.data.username,
            expired: jsonResponse.data.expired,
            password: jsonResponse.data.password,
            method: jsonResponse.data.method,
            quota: jsonResponse.data.quota,
            ip_limit: jsonResponse.data.ip_limit,
            domain: jsonResponse.data.domain,
            ns_domain: jsonResponse.data.ns_domain,
            city: jsonResponse.data.city,
            pubkey: jsonResponse.data.pubkey,
            ss_link_ws: jsonResponse.data.ss_link_ws,
            ss_link_grpc: jsonResponse.data.ss_link_grpc
          }
        });
      } else {
        res.status(500).json({ error: 'Terjadi kesalahan saat membuat akun', detail: jsonResponse.message });
      }
    } catch (error) {
      console.error('Error parsing JSON:', error);
      res.status(500).json({ error: 'Terjadi kesalahan saat memproses output JSON' });
    }
  });
});
// Check SSH user
app.get("/checkssh", (req, res) => { 
  
  const child = spawn("/bin/bash", ["-c", `apicheck ssh`], {
    stdio: ['pipe', 'pipe', 'pipe']
  });
  
  child.stdin.end();
  let output = '';
  child.stdout.on('data', (data) => {
    output += data.toString();
  });
  
  child.stderr.on('data', (data) => {
    console.error(`Kesalahan: ${data}`);
    output += data.toString();
  });
  
  child.on('close', (code) => {
    if (code !== 0) {
      console.log(`Proses pemeriksaan akun SSH gagal dengan kode: ${code}`);
      return res.status(500).json({ error: 'Terjadi kesalahan saat memeriksa akun', detail: output });
    }
    console.log(`Akun SSH berhasil diperiksa`);
    try {
      // Menghapus koma ekstra sebelum mem-parsing JSON
      const cleanedOutput = output.replace(/,\s*}/g, '}').replace(/,\s*]/g, ']');
      const jsonResponse = JSON.parse(cleanedOutput);
      if (jsonResponse.status === "success" && jsonResponse.data) {
        res.json({
          status: "success",
          message: jsonResponse.data.message,
          data: jsonResponse.data
        });
      } else {
        res.status(404).json({ error: 'Akun SSH tidak ditemukan' });
      }
    } catch (error) {
      console.error(`Error parsing JSON: ${error}`);
      res.status(500).json({ error: 'Terjadi kesalahan saat memproses output JSON' });
    }
  });
});

app.get("/checkvmess", (req, res) => { 

  console.log(`Menerima permintaan untuk memeriksa akun VMess dengan user: `);
  
  const child = spawn("/bin/bash", ["-c", `apicheck vmess`], {
    stdio: ['pipe', 'pipe', 'pipe']
  });
  
  child.stdin.end();
  let output = '';
  child.stdout.on('data', (data) => {
    output += data.toString();
  });
  
  child.stderr.on('data', (data) => {
    console.error(`Kesalahan: ${data}`);
    output += data.toString();
  });
  
  child.on('close', (code) => {
    if (code !== 0) {
      console.log(`Proses pemeriksaan akun VMess gagal dengan kode: ${code}`);
      return res.status(500).json({ error: 'Terjadi kesalahan saat memeriksa akun', detail: output });
    }
    console.log(`Akun VMess berhasil diperiksa`);
    
    try {
      // Menghapus koma ekstra sebelum mem-parsing JSON
      const cleanedOutput = output.replace(/,\s*}/g, '}').replace(/,\s*]/g, ']');
      const jsonResponse = JSON.parse(cleanedOutput);
      if (jsonResponse.status === "success" && jsonResponse.data) {
        res.json({
          status: "success",
          message: jsonResponse.data.message,
          data: jsonResponse.data
        });
      } else {
        res.status(404).json({ error: 'Akun VMess tidak ditemukan' });
      }
    } catch (error) {
      console.error('Error parsing JSON:', error);
      res.status(500).json({ error: 'Terjadi kesalahan saat memproses output JSON' });
    }
  });
});
app.get("/checkvless", (req, res) => { 

  console.log(`Menerima permintaan untuk memeriksa akun VLESS dengan user: `);
  
  const child = spawn("/bin/bash", ["-c", `apicheck vless`], {
    stdio: ['pipe', 'pipe', 'pipe']
  });
  
  child.stdin.end();
  let output = '';
  child.stdout.on('data', (data) => {
    output += data.toString();
  });
  
  child.stderr.on('data', (data) => {
    console.error(`Kesalahan: ${data}`);
    output += data.toString();
  });
  
  child.on('close', (code) => {
    if (code !== 0) {
      console.log(`Proses pemeriksaan akun VLESS gagal dengan kode: ${code}`);
      return res.status(500).json({ error: 'Terjadi kesalahan saat memeriksa akun', detail: output });
    }
    console.log(`Akun VLESS berhasil diperiksa`);
    
    try {
      // Menghapus koma ekstra sebelum mem-parsing JSON
      const cleanedOutput = output.replace(/,\s*}/g, '}').replace(/,\s*]/g, ']');
      const jsonResponse = JSON.parse(cleanedOutput);
      if (jsonResponse.status === "success" && jsonResponse.data) {
        res.json({
          status: "success",
          message: jsonResponse.data.message,
          data: jsonResponse.data
        });
      } else {
        res.status(404).json({ error: 'Akun VLESS tidak ditemukan' });
      }
    } catch (error) {
      console.error('Error parsing JSON:', error);
      res.status(500).json({ error: 'Terjadi kesalahan saat memproses output JSON' });
    }
  });
});

app.get("/checktrojan", (req, res) => { 

  console.log(`Menerima permintaan untuk memeriksa akun Trojan dengan user: `);
  
  const child = spawn("/bin/bash", ["-c", `apicheck trojan`], {
    stdio: ['pipe', 'pipe', 'pipe']
  });
  
  child.stdin.end();
  let output = '';
  child.stdout.on('data', (data) => {
    output += data.toString();
  });
  
  child.stderr.on('data', (data) => {
    console.error(`Kesalahan: ${data}`);
    output += data.toString();
  });
  
  child.on('close', (code) => {
    if (code !== 0) {
      console.log(`Proses pemeriksaan akun Trojan gagal dengan kode: ${code}`);
      return res.status(500).json({ error: 'Terjadi kesalahan saat memeriksa akun', detail: output });
    }
    console.log(`Akun Trojan berhasil diperiksa`);
    
    try {
      // Menghapus koma ekstra sebelum mem-parsing JSON
      const cleanedOutput = output.replace(/,\s*}/g, '}').replace(/,\s*]/g, ']');
      const jsonResponse = JSON.parse(cleanedOutput);
      if (jsonResponse.status === "success" && jsonResponse.data) {
        res.json({
          status: "success",
          message: jsonResponse.data.message,
          data: jsonResponse.data
        });
      } else {
        res.status(404).json({ error: 'Akun Trojan tidak ditemukan' });
      }
    } catch (error) {
      console.error('Error parsing JSON:', error);
      res.status(500).json({ error: 'Terjadi kesalahan saat memproses output JSON' });
    }
  });
});

app.get("/checkshadowsocks", (req, res) => { 

  console.log(`Menerima permintaan untuk memeriksa akun Shadowsocks dengan user: `);
  
  const child = spawn("/bin/bash", ["-c", `apicheck shadowsocks`], {
    stdio: ['pipe', 'pipe', 'pipe']
  });
  
  child.stdin.end();
  let output = '';
  child.stdout.on('data', (data) => {
    output += data.toString();
  });
  
  child.stderr.on('data', (data) => {
    console.error(`Kesalahan: ${data}`);
    output += data.toString();
  });
  
  child.on('close', (code) => {
    if (code !== 0) {
      console.log(`Proses pemeriksaan akun Shadowsocks gagal dengan kode: ${code}`);
      return res.status(500).json({ error: 'Terjadi kesalahan saat memeriksa akun', detail: output });
    }
    console.log(`Akun Shadowsocks berhasil diperiksa`);
    
    try {
      // Menghapus koma ekstra sebelum mem-parsing JSON
      const cleanedOutput = output.replace(/,\s*}/g, '}').replace(/,\s*]/g, ']');
      const jsonResponse = JSON.parse(cleanedOutput);
      if (jsonResponse.status === "success" && jsonResponse.data) {
        res.json({
          status: "success",
          message: jsonResponse.data.message,
          data: jsonResponse.data
        });
      } else {
        res.status(404).json({ error: 'Akun Shadowsocks tidak ditemukan' });
      }
    } catch (error) {
      console.error('Error parsing JSON:', error);
      res.status(500).json({ error: 'Terjadi kesalahan saat memproses output JSON' });
    }
  });
});

// delete user ssh
app.get("/deletessh", (req, res) => {
  const { user } = req.query;
  if (!user) {
    return res.status(400).json({ error: 'Username diperlukan' });
  }
  
  console.log(`Menerima permintaan untuk menghapus akun SSH dengan user: ${user}`);
  
  const child = spawn("/bin/bash", ["-c", `apidelete ssh ${user}`], {
    stdio: ['pipe', 'pipe', 'pipe']
  });
  
  child.stdin.end();
  let output = '';
  child.stdout.on('data', (data) => {
    output += data.toString();
  });
  
  child.stderr.on('data', (data) => {
    console.error(`Kesalahan: ${data}`);
    output += data.toString();
  });
  
  child.on('close', (code) => {
    if (code !== 0) {
      console.log(`Proses penghapusan akun SSH gagal dengan kode: ${code}`);
      return res.status(500).json({ error: 'Terjadi kesalahan saat menghapus akun', detail: output });
    }
    console.log(`Akun SSH berhasil dihapus untuk user: ${user}`);
    
    try {
      // Menghapus koma ekstra sebelum mem-parsing JSON
      const cleanedOutput = output.replace(/,\s*}/g, '}').replace(/,\s*]/g, ']');
      const jsonResponse = JSON.parse(cleanedOutput);
      if (jsonResponse.status === "success" && jsonResponse.data) {
        res.json({
          status: "success",
          message: jsonResponse.data.message,
          data: jsonResponse.data
        });
      } else {
        res.status(404).json({ error: 'Akun SSH tidak ditemukan' });
      }
    } catch (error) {
      console.error('Error parsing JSON:', error);
      res.status(500).json({ error: 'Terjadi kesalahan saat memproses output JSON' });
    }
  });
});
// delete user vmess
app.get("/deletevmess", (req, res) => {
  const { user } = req.query;
  if (!user) {
    return res.status(400).json({ error: 'Username diperlukan' });
  }
  
  console.log(`Menerima permintaan untuk menghapus akun VMess dengan user: ${user}`);
  
  const child = spawn("/bin/bash", ["-c", `apidelete vmess ${user}`], {
    stdio: ['pipe', 'pipe', 'pipe']
  });
  
  child.stdin.end();
  let output = '';
  child.stdout.on('data', (data) => {
    output += data.toString();
  });
  
  child.stderr.on('data', (data) => {
    console.error(`Kesalahan: ${data}`);
    output += data.toString();
  });
  
  child.on('close', (code) => {
    if (code !== 0) {
      console.log(`Proses penghapusan akun VMess gagal dengan kode: ${code}`);
      return res.status(500).json({ error: 'Terjadi kesalahan saat menghapus akun', detail: output });
    }
    console.log(`Akun VMess berhasil dihapus untuk user: ${user}`);
    
      // Menghapus koma ekstra sebelum mem-parsing JSON
      try {
        const cleanedOutput = output.replace(/,\s*}/g, '}').replace(/,\s*]/g, ']');
        const jsonResponse = JSON.parse(cleanedOutput);
        if (jsonResponse.status === "success" && jsonResponse.data) {
          res.json({
            status: "success",
            message: jsonResponse.data.message,
            data: jsonResponse.data
          });
        } else {
          res.status(404).json({ error: 'Akun VMess tidak ditemukan' });
        }
      } catch (error) {
        console.error('Error parsing JSON:', error);
        res.status(500).json({ error: 'Terjadi kesalahan saat memproses output JSON' });
      }
    });
});

// delete user vless
app.get("/deletevless", (req, res) => {
  const { user } = req.query;
  if (!user) {
    return res.status(400).json({ error: 'Username diperlukan' });
  }
  
  console.log(`Menerima permintaan untuk menghapus akun VLess dengan user: ${user}`);
  
  const child = spawn("/bin/bash", ["-c", `apidelete vless ${user}`], {
    stdio: ['pipe', 'pipe', 'pipe']
  });
  
  child.stdin.end();
  let output = '';
  child.stdout.on('data', (data) => {
    output += data.toString();
  });
  
  child.stderr.on('data', (data) => {
    console.error(`Kesalahan: ${data}`);
    output += data.toString();
  });
  
  child.on('close', (code) => {
    if (code !== 0) {
      console.log(`Proses penghapusan akun VLess gagal dengan kode: ${code}`);
      return res.status(500).json({ error: 'Terjadi kesalahan saat menghapus akun', detail: output });
    }
    console.log(`Akun VLess berhasil dihapus untuk user: ${user}`);
    
    
    try {
      const cleanedOutput = output.replace(/,\s*}/g, '}').replace(/,\s*]/g, ']');
      const jsonResponse = JSON.parse(cleanedOutput);
      if (jsonResponse.status === "success" && jsonResponse.data) {
        res.json({
          status: "success",
          message: jsonResponse.data.message,
          data: jsonResponse.data
        });
      } else {
        res.status(404).json({ error: 'Akun VLess tidak ditemukan' });
      }
    } catch (error) {
      console.error('Error parsing JSON:', error);
      res.status(500).json({ error: 'Terjadi kesalahan saat memproses output JSON' });
    }
  });
});
// delete user trojan
app.get("/deletetrojan", (req, res) => {
  const { user } = req.query;
  if (!user) {
    return res.status(400).json({ error: 'Username diperlukan' });
  }
  
  console.log(`Menerima permintaan untuk menghapus akun Trojan dengan user: ${user}`);
  
  const child = spawn("/bin/bash", ["-c", `apidelete trojan ${user}`], {
    stdio: ['pipe', 'pipe', 'pipe']
  });
  
  child.stdin.end();
  let output = '';
  child.stdout.on('data', (data) => {
    output += data.toString();
  });
  
  child.stderr.on('data', (data) => {
    console.error(`Kesalahan: ${data}`);
    output += data.toString();
  });
  
  child.on('close', (code) => {
    if (code !== 0) {
      console.log(`Proses penghapusan akun Trojan gagal dengan kode: ${code}`);
      return res.status(500).json({ error: 'Terjadi kesalahan saat menghapus akun', detail: output });
    }
    console.log(`Akun Trojan berhasil dihapus untuk user: ${user}`);
    
    
    try {
      const cleanedOutput = output.replace(/,\s*}/g, '}').replace(/,\s*]/g, ']');
      const jsonResponse = JSON.parse(cleanedOutput);
      if (jsonResponse.status === "success" && jsonResponse.data) {
        res.json({
          status: "success",
          message: jsonResponse.data.message,
          data: jsonResponse.data
        });
      } else {
        res.status(404).json({ error: 'Akun Trojan tidak ditemukan' });
      }
    } catch (error) {
      console.error('Error parsing JSON:', error);
      res.status(500).json({ error: 'Terjadi kesalahan saat memproses output JSON' });
    }
  });
});
// delete user shadowsocks
app.get("/deleteshadowsocks", (req, res) => {
  const { user } = req.query;
  if (!user) {
    return res.status(400).json({ error: 'Username diperlukan' });
  }
  
  console.log(`Menerima permintaan untuk menghapus akun Shadowsocks dengan user: ${user}`);
  
  const child = spawn("/bin/bash", ["-c", `apidelete shadowsocks ${user}`], {
    stdio: ['pipe', 'pipe', 'pipe']
  });
  
  child.stdin.end();
  let output = '';
  child.stdout.on('data', (data) => {
    output += data.toString();
  });
  
  child.stderr.on('data', (data) => {
    console.error(`Kesalahan: ${data}`);
    output += data.toString();
  });
  
  child.on('close', (code) => {
    if (code !== 0) {
      console.log(`Proses penghapusan akun Shadowsocks gagal dengan kode: ${code}`);
      return res.status(500).json({ error: 'Terjadi kesalahan saat menghapus akun', detail: output });
    }
    console.log(`Akun Shadowsocks berhasil dihapus untuk user: ${user}`);
    
    try {
      const cleanedOutput = output.replace(/,\s*}/g, '}').replace(/,\s*]/g, ']');
      const jsonResponse = JSON.parse(cleanedOutput);
      if (jsonResponse.status === "success" && jsonResponse.data) {
        res.json({
          status: "success",
          message: jsonResponse.data.message,
          data: jsonResponse.data
        });
      } else {
        res.status(404).json({ error: 'Akun Shadowsocks tidak ditemukan' });
      }
    } catch (error) {
      console.error('Error parsing JSON:', error);
      res.status(500).json({ error: 'Terjadi kesalahan saat memproses output JSON' });
    }
  });
});
// Renew ssh user
app.get("/renewssh", (req, res) => {
  const { user, exp, iplimit } = req.query;
  if (!user || !exp || !iplimit) {
    return res.status(400).json({ error: 'Username, expiry, dan iplimit diperlukan' });
  }
  
  console.log(`Menerima permintaan untuk memperbarui akun SSH dengan user: ${user}, exp: ${exp}, iplimit: ${iplimit}`);
  
  const child = spawn("/bin/bash", ["-c", `apirenew ssh ${user} ${exp} ${iplimit}`], {
    stdio: ['pipe', 'pipe', 'pipe']
  });
  
  child.stdin.end();
  let output = '';
  child.stdout.on('data', (data) => {
    output += data.toString();
  });
  
  child.stderr.on('data', (data) => {
    console.error(`Kesalahan: ${data}`);
    output += data.toString();
  });
  
  child.on('close', (code) => {
    if (code !== 0) {
      console.log(`Proses pembaruan akun SSH gagal dengan kode: ${code}`);
      return res.status(500).json({ error: 'Terjadi kesalahan saat memperbarui akun', detail: output });
    }
    console.log(`Akun SSH berhasil diperbarui untuk user: ${user}`);
    try {
      const jsonResponse = JSON.parse(output);
      if (jsonResponse.status === "success") {
        res.json({
          status: "success",
          message: "Akun Vmess test berhasil diperbarui",
          data: {
            username: jsonResponse.data.username,
            exp: jsonResponse.data.exp,
            limitip: jsonResponse.data.limitip
          }
        });
      } else {
        res.status(500).json({ error: 'Terjadi kesalahan saat memperbarui akun', detail: jsonResponse.message });
      }
    } catch (error) {
      console.error('Error parsing JSON:', error);
      res.status(500).json({ error: 'Terjadi kesalahan saat memproses output JSON' });
    }
  });
});
// Renew vmess user
app.get("/renewvmess", (req, res) => {
  const { user, exp, quota, iplimit } = req.query;
  if (!user || !exp || !quota || !iplimit) {
    return res.status(400).json({ error: 'Username, expiry, quota, dan iplimit diperlukan' });
  }
  
  console.log(`Menerima permintaan untuk memperbarui akun VMess dengan user: ${user}, exp: ${exp}, quota: ${quota}, iplimit: ${iplimit}`);
  
  const child = spawn("/bin/bash", ["-c", `apirenew vmess ${user} ${exp} ${quota} ${iplimit}`], {
    stdio: ['pipe', 'pipe', 'pipe']
  });
  
  child.stdin.end();
  let output = '';
  child.stdout.on('data', (data) => {
    output += data.toString();
  });
  
  child.stderr.on('data', (data) => {
    console.error(`Kesalahan: ${data}`);
    output += data.toString();
  });
  
  child.on('close', (code) => {
    if (code !== 0) {
      console.log(`Proses pembaruan akun VMess gagal dengan kode: ${code}`);
      return res.status(500).json({ error: 'Terjadi kesalahan saat memperbarui akun', detail: output });
    }
    console.log(`Akun VMess berhasil diperbarui untuk user: ${user}`);
    try {
      const jsonResponse = JSON.parse(output);
      if (jsonResponse.status === "success") {
        res.json({
          status: "success",
          message: "Akun Vmess test berhasil diperbarui",
          data: {
            username: jsonResponse.data.username,
            exp: jsonResponse.data.exp,
            quota: jsonResponse.data.quota,
            limitip: jsonResponse.data.limitip
          }
        });
      } else {
        res.status(500).json({ error: 'Terjadi kesalahan saat memperbarui akun', detail: jsonResponse.message });
      }
    } catch (error) {
      console.error('Error parsing JSON:', error);
      res.status(500).json({ error: 'Terjadi kesalahan saat memproses output JSON' });
    }
  });
});

// Renew vless user
app.get("/renewvless", (req, res) => {
  const { user, exp, quota, iplimit } = req.query;
  if (!user || !exp || !quota || !iplimit) {
    return res.status(400).json({ error: 'Username, expiry, quota, dan iplimit diperlukan' });
  }
  
  console.log(`Menerima permintaan untuk memperbarui akun VLess dengan user: ${user}, exp: ${exp}, quota: ${quota}, iplimit: ${iplimit}`);
  
  const child = spawn("/bin/bash", ["-c", `apirenew vless ${user} ${exp} ${quota} ${iplimit}`], {
    stdio: ['pipe', 'pipe', 'pipe']
  });
  
  child.stdin.end();
  let output = '';
  child.stdout.on('data', (data) => {
    output += data.toString();
  });
  
  child.stderr.on('data', (data) => {
    console.error(`Kesalahan: ${data}`);
    output += data.toString();
  });
  
  child.on('close', (code) => {
    if (code !== 0) {
      console.log(`Proses pembaruan akun VLess gagal dengan kode: ${code}`);
      return res.status(500).json({ error: 'Terjadi kesalahan saat memperbarui akun', detail: output });
    }
    console.log(`Akun VLess berhasil diperbarui untuk user: ${user}`);
    
    try {
      const jsonResponse = JSON.parse(output);
      if (jsonResponse.status === "success") {
        res.json({
          status: "success",
          message: "Akun Vmess test berhasil diperbarui",
          data: {
            username: jsonResponse.data.username,
            exp: jsonResponse.data.exp,
            quota: jsonResponse.data.quota,
            limitip: jsonResponse.data.limitip
          }
        });
      } else {
        res.status(500).json({ error: 'Terjadi kesalahan saat memperbarui akun', detail: jsonResponse.message });
      }
    } catch (error) {
      console.error('Error parsing JSON:', error);
      res.status(500).json({ error: 'Terjadi kesalahan saat memproses output JSON' });
    }
  });
});

// Renew trojan user
app.get("/renewtrojan", (req, res) => {
  const { user, exp, quota, iplimit } = req.query;
  if (!user || !exp || !quota || !iplimit) {
    return res.status(400).json({ error: 'Username, expiry, quota, dan iplimit diperlukan' });
  }
  
  console.log(`Menerima permintaan untuk memperbarui akun Trojan dengan user: ${user}, exp: ${exp}, quota: ${quota}, iplimit: ${iplimit}`);
  
  const child = spawn("/bin/bash", ["-c", `apirenew trojan ${user} ${exp} ${quota} ${iplimit}`], {
    stdio: ['pipe', 'pipe', 'pipe']
  });
  
  child.stdin.end();
  let output = '';
  child.stdout.on('data', (data) => {
    output += data.toString();
  });
  
  child.stderr.on('data', (data) => {
    console.error(`Kesalahan: ${data}`);
    output += data.toString();
  });
  
  child.on('close', (code) => {
    if (code !== 0) {
      console.log(`Proses pembaruan akun Trojan gagal dengan kode: ${code}`);
      return res.status(500).json({ error: 'Terjadi kesalahan saat memperbarui akun', detail: output });
    }
    console.log(`Akun Trojan berhasil diperbarui untuk user: ${user}`);
    
    try {
      const jsonResponse = JSON.parse(output);
      if (jsonResponse.status === "success") {
        res.json({
          status: "success",
          message: "Akun Vmess test berhasil diperbarui",
          data: {
            username: jsonResponse.data.username,
            exp: jsonResponse.data.exp,
            quota: jsonResponse.data.quota,
            limitip: jsonResponse.data.limitip
          }
        });
      } else {
        res.status(500).json({ error: 'Terjadi kesalahan saat memperbarui akun', detail: jsonResponse.message });
      }
    } catch (error) {
      console.error('Error parsing JSON:', error);
      res.status(500).json({ error: 'Terjadi kesalahan saat memproses output JSON' });
    }
  });
});

// Renew shadowsocks user
app.get("/renewshadowsocks", (req, res) => {
  const { user, exp, quota, iplimit } = req.query;
  if (!user || !exp || !quota || !iplimit) {
    return res.status(400).json({ error: 'Username, expiry, quota, dan iplimit diperlukan' });
  }
  
  console.log(`Menerima permintaan untuk memperbarui akun Shadowsocks dengan user: ${user}, exp: ${exp}, quota: ${quota}, iplimit: ${iplimit}`);
  
  const child = spawn("/bin/bash", ["-c", `apirenew shadowsocks ${user} ${exp} ${quota} ${iplimit}`], {
    stdio: ['pipe', 'pipe', 'pipe']
  });
  
  child.stdin.end();
  let output = '';
  child.stdout.on('data', (data) => {
    output += data.toString();
  });
  
  child.stderr.on('data', (data) => {
    console.error(`Kesalahan: ${data}`);
    output += data.toString();
  });
  
  child.on('close', (code) => {
    if (code !== 0) {
      console.log(`Proses pembaruan akun Shadowsocks gagal dengan kode: ${code}`);
      return res.status(500).json({ error: 'Terjadi kesalahan saat memperbarui akun', detail: output });
    }
    console.log(`Akun Shadowsocks berhasil diperbarui untuk user: ${user}`);
    
    try {
      const jsonResponse = JSON.parse(output);
      if (jsonResponse.status === "success") {
        res.json({
          status: "success",
          message: "Akun Vmess test berhasil diperbarui",
          data: {
            username: jsonResponse.data.username,
            exp: jsonResponse.data.exp,
            quota: jsonResponse.data.quota,
            limitip: jsonResponse.data.limitip
          }
        });
      } else {
        res.status(500).json({ error: 'Terjadi kesalahan saat memperbarui akun', detail: jsonResponse.message });
      }
    } catch (error) {
      console.error('Error parsing JSON:', error);
      res.status(500).json({ error: 'Terjadi kesalahan saat memproses output JSON' });
    }
  });
});
// Create SSH trial (for the new api2trial-ssh that returns JSON with ports object)
app.get("/trialssh", (req, res) => {
  console.log(`⚡ Trial SSH request from ${req.ip}`);

  // ==========================================
  // AMBIL DURASI DARI BOT (Default 60 menit)
  // ==========================================
  const duration = req.query.duration || req.query.minutes || "60";
  const finalMin = /^\d+$/.test(duration) ? duration : "60";

  // Jalankan script dengan argumen durasi
  // Pastikan script /usr/bin/api2trial-ssh kamu bisa terima argumen $1
  const child = spawn("/usr/bin/api2trial-ssh", [String(finalMin)], {
    stdio: ['ignore', 'pipe', 'pipe'],
    timeout: 20000
  });

  let output = '';
  child.stdout.on('data', (data) => {
    output += data.toString();
  });

  child.stderr.on('data', (data) => {
    console.error(`apitrial-ssh stderr: ${data}`);
    output += data.toString();
  });

  child.on('close', (code) => {
    if (code !== 0) {
      console.log(`apitrial-ssh exited with code ${code}`);
      return res.status(500).json({ status: "error", message: 'Gagal membuat trial SSH', detail: output });
    }

    try {
      // Bersihkan output agar JSON valid
      const jsonStartIndex = output.indexOf('{');
      const jsonEndIndex = output.lastIndexOf('}') + 1;
      const jsonContent = output.substring(jsonStartIndex, jsonEndIndex);
      
      const jsonResponse = JSON.parse(jsonContent.replace(/,\s*}/g, '}').replace(/,\s*]/g, ']'));

      if (!jsonResponse || jsonResponse.status !== "success") {
        return res.status(500).json({ status: "error", message: 'Script returned failure', detail: jsonResponse || output });
      }

      // Ambil data dan tambahkan info durasi jika tidak ada di output script
      return res.json({
        status: "success",
        message: "SSH trial successfully created",
        data: {
          username: jsonResponse.username || jsonResponse.data?.username || "-",
          password: jsonResponse.password || jsonResponse.data?.password || "-",
          ip: jsonResponse.ip || "-",
          domain: jsonResponse.domain || "-",
          expiration: jsonResponse.expiration || jsonResponse.data?.expired || "-",
          duration_minutes: finalMin, // Tambahkan ini agar bot bisa nampilin durasi
          ports: jsonResponse.ports || {},
          wss_payload: jsonResponse.wss_payload || null
        }
      });
    } catch (err) {
      console.error('Error parsing JSON:', err.message);
      return res.status(500).json({ status: "error", message: 'JSON parse error', raw: output });
    }
  });
});


// Create VMess trial (calls /usr/bin/api2trial-vmess)
app.get("/trialvmess", (req, res) => {
  console.log(`⚡ Trial VMess request from ${req.ip}`);

  const duration = req.query.duration || req.query.minutes || "60";
  const finalMin = /^\d+$/.test(duration) ? duration : "60";

  const child = spawn("/usr/bin/api2trial-vmess", [String(finalMin)], {
    stdio: ['ignore', 'pipe', 'pipe'],
    timeout: 20000
  });

  let output = '';
  child.stdout.on('data', (data) => { output += data.toString(); });
  child.stderr.on('data', (data) => { output += data.toString(); });

  child.on('close', (code) => {
    if (code !== 0) {
      return res.status(500).json({ status: "error", message: 'Gagal membuat trial VMess', detail: output });
    }

    try {
      const jsonStartIndex = output.indexOf('{');
      const jsonEndIndex = output.lastIndexOf('}') + 1;
      const jsonContent = output.substring(jsonStartIndex, jsonEndIndex);
      const jsonResponse = JSON.parse(jsonContent.replace(/,\s*}/g, '}').replace(/,\s*]/g, ']'));

      if (!jsonResponse || jsonResponse.status !== "success") {
        return res.status(500).json({ status: "error", message: 'Script failure', detail: jsonResponse || output });
      }

      // ==========================================
      // FIX: TAMBAHKAN gRPC & SERVICE NAME
      // ==========================================
      return res.json({
        status: "success",
        message: "VMess trial successfully created",
        data: {
          username: jsonResponse.username || jsonResponse.data?.username || "-",
          uuid: jsonResponse.uuid || jsonResponse.data?.uuid || "-",
          domain: jsonResponse.domain || "-",
          expiration: jsonResponse.expiration || jsonResponse.exp || jsonResponse.data?.expired || "-",
          duration_minutes: finalMin,
          link_tls: jsonResponse.link_tls || null,
          link_ntls: jsonResponse.link_ntls || null,
          // Tambahkan link gRPC di sini
          link_grpc: jsonResponse.link_grpc || jsonResponse.link_vmess_grpc || null, 
          path: jsonResponse.path || "/vmess",
          service_name: jsonResponse.service_name || jsonResponse.vmess_grpc_service || "vmess-grpc",
          port_tls: jsonResponse.port_tls || "443",
          port_http: jsonResponse.port_http || "80"
        }
      });
    } catch (err) {
      return res.status(500).json({ status: "error", message: 'JSON parse error', raw: output });
    }
  });
});


// Create VLESS trial (calls /usr/bin/api2trial-vless) — robust + normalized output
app.get("/trialvless", (req, res) => {
  console.log(`⚡ Trial VLESS request from ${req.ip}`);

  // ==========================================
  // AMBIL DURASI DARI BOT (Default 60 menit)
  // ==========================================
  const duration = req.query.duration || req.query.minutes || "60";
  const finalMin = /^\d+$/.test(duration) ? duration : "60";

  // Memanggil script dengan argumen durasi menit ($1 di bash)
  const cmd = "/usr/bin/api2trial-vless";
  const child = spawn(cmd, [String(finalMin)], {
    stdio: ['ignore', 'pipe', 'pipe'],
    timeout: 20000
  });

  let output = '';
  child.stdout.on('data', (data) => { output += data.toString(); });
  child.stderr.on('data', (data) => {
    console.error(`apitrial-vless stderr: ${data}`);
    output += data.toString();
  });

  child.on('close', (code) => {
    if (code !== 0) {
      console.log(`apitrial-vless exited with code ${code}`);
      return res.status(500).json({ 
        status: "error", 
        message: 'Terjadi kesalahan saat membuat trial VLESS', 
        detail: output 
      });
    }

    try {
      // Robust JSON Parsing (mencari blok { ... })
      const jsonStartIndex = output.indexOf('{');
      const jsonEndIndex = output.lastIndexOf('}') + 1;
      
      if (jsonStartIndex === -1) throw new Error("Output script tidak mengandung JSON");
      
      const jsonContent = output.substring(jsonStartIndex, jsonEndIndex);
      const cleanedOutput = jsonContent.replace(/,\s*}/g, '}').replace(/,\s*]/g, ']');
      const jsonResponse = JSON.parse(cleanedOutput);

      if (!jsonResponse || jsonResponse.status !== "success") {
        return res.status(500).json({ 
          status: "error", 
          message: 'Script returned failure', 
          detail: jsonResponse || cleanedOutput 
        });
      }

      // Mapping data untuk bot
      return res.json({
        status: "success",
        message: "VLESS trial successfully created",
        data: {
          username: jsonResponse.username || jsonResponse.data?.username || "-",
          uuid: jsonResponse.uuid || jsonResponse.data?.uuid || "-",
          domain: jsonResponse.domain || "-",
          expiration: jsonResponse.expiration || jsonResponse.exp || jsonResponse.data?.expired || "-",
          duration_minutes: finalMin, // Simpan info durasi menit
          protocol: "vless",
          link_tls: jsonResponse.link_tls || null,
          link_ntls: jsonResponse.link_ntls || null,
          link_grpc: jsonResponse.link_grpc || null,
          path: jsonResponse.path || "/vless",
          service_name: jsonResponse.service_name || "vless-grpc"
        }
      });
    } catch (err) {
      console.error('Error processing VLESS output:', err.message);
      return res.status(500).json({ 
        status: "error", 
        message: 'Gagal memproses output JSON', 
        raw: output 
      });
    }
  });
});


// Create Trojan trial (calls /usr/bin/api2trial-trojan)
app.get("/trialtrojan", (req, res) => {
  console.log(`⚡ Trial Trojan request from ${req.ip}`);

  // ==========================================
  // AMBIL DURASI DARI BOT (Default 60 menit)
  // ==========================================
  const duration = req.query.duration || req.query.minutes || "60";
  const finalMin = /^\d+$/.test(duration) ? duration : "60";

  // Memanggil script dengan argumen durasi menit
  const cmd = "/usr/bin/api2trial-trojan";
  const child = spawn(cmd, [String(finalMin)], {
    stdio: ['ignore', 'pipe', 'pipe'],
    timeout: 20000
  });

  let output = '';
  child.stdout.on('data', (data) => { output += data.toString(); });
  child.stderr.on('data', (data) => {
    console.error(`apitrial-trojan stderr: ${data}`);
    output += data.toString();
  });

  child.on('close', (code) => {
    if (code !== 0) {
      console.log(`apitrial-trojan exited with code ${code}`);
      return res.status(500).json({ 
        status: "error", 
        message: 'Terjadi kesalahan saat membuat trial Trojan', 
        detail: output 
      });
    }

    try {
      // Robust JSON Parsing (mencari blok { ... })
      const jsonStartIndex = output.indexOf('{');
      const jsonEndIndex = output.lastIndexOf('}') + 1;
      
      if (jsonStartIndex === -1) throw new Error("Output script tidak mengandung JSON");
      
      const jsonContent = output.substring(jsonStartIndex, jsonEndIndex);
      const cleanedOutput = jsonContent.replace(/,\s*}/g, '}').replace(/,\s*]/g, ']');
      const jsonResponse = JSON.parse(cleanedOutput);

      if (!jsonResponse || jsonResponse.status !== "success") {
        return res.status(500).json({ 
          status: "error", 
          message: 'Script returned failure', 
          detail: jsonResponse || cleanedOutput 
        });
      }

      // Mapping data agar terbaca oleh formatMessage bot
      return res.json({
        status: "success",
        message: "Trojan trial successfully created",
        data: {
          username: jsonResponse.username || jsonResponse.data?.username || "-",
          uuid: jsonResponse.uuid || jsonResponse.password || jsonResponse.data?.password || "-",
          domain: jsonResponse.domain || "-",
          expiration: jsonResponse.expiration || jsonResponse.exp || jsonResponse.data?.expired || "-",
          duration_minutes: finalMin,
          protocol: "trojan",
          link_tls: jsonResponse.link_tls || null,
          link_grpc: jsonResponse.link_grpc || null,
          path: jsonResponse.path || "/trojan",
          port_tls: jsonResponse.port_tls || "443"
        }
      });
    } catch (err) {
      console.error('Error processing Trojan JSON:', err.message);
      return res.status(500).json({ 
        status: "error", 
        message: 'Gagal memproses output JSON', 
        raw: output 
      });
    }
  });
});


// Create Shadowsocks trial (calls /usr/bin/apitrial-shadowsocks) — cleaned & robust
app.get("/trialshadowsocks", (req, res) => {
  console.log(`⚡ Trial Shadowsocks request from ${req.ip}`);

  // ==========================================
  // AMBIL DURASI DARI BOT (Default 60 menit)
  // ==========================================
  const duration = req.query.duration || req.query.minutes || "60";
  const finalMin = /^\d+$/.test(duration) ? duration : "60";

  // Memanggil script dengan argumen durasi menit ($1)
  const cmd = "/usr/bin/api2trial-shadowsocks";
  const child = spawn(cmd, [String(finalMin)], {
    stdio: ['ignore', 'pipe', 'pipe'],
    timeout: 20000
  });

  let output = '';
  child.stdout.on('data', (data) => { output += data.toString(); });
  child.stderr.on('data', (data) => {
    console.error(`apitrial-shadowsocks stderr: ${data}`);
    output += data.toString();
  });

  child.on('close', (code) => {
    if (code !== 0) {
      console.log(`apitrial-shadowsocks exited with code ${code}`);
      return res.status(500).json({ 
        status: "error", 
        message: 'Gagal membuat trial Shadowsocks', 
        detail: output 
      });
    }

    try {
      // Robust JSON Parsing
      const jsonStartIndex = output.indexOf('{');
      const jsonEndIndex = output.lastIndexOf('}') + 1;
      
      if (jsonStartIndex === -1) throw new Error("Output script tidak mengandung JSON");
      
      const jsonContent = output.substring(jsonStartIndex, jsonEndIndex);
      const cleanedOutput = jsonContent.replace(/,\s*}/g, '}').replace(/,\s*]/g, ']');
      const jsonResponse = JSON.parse(cleanedOutput);

      if (!jsonResponse || jsonResponse.status !== "success") {
        return res.status(500).json({ 
          status: "error", 
          message: 'Script returned failure', 
          detail: jsonResponse || cleanedOutput 
        });
      }

      // Mapping data agar sinkron dengan formatMessage bot
      return res.json({
        status: "success",
        message: "Shadowsocks trial successfully created",
        data: {
          username: jsonResponse.username || jsonResponse.data?.username || "-",
          password: jsonResponse.password || jsonResponse.data?.password || "-",
          domain: jsonResponse.domain || "-",
          expiration: jsonResponse.expiration || jsonResponse.exp || jsonResponse.data?.expired || "-",
          duration_minutes: finalMin,
          protocol: "shadowsocks",
          link_ws: jsonResponse.link_ws || jsonResponse.link || null,
          link_grpc: jsonResponse.link_grpc || null,
          method: jsonResponse.method || "aes-128-gcm",
          port_tls: jsonResponse.port_tls || "443"
        }
      });
    } catch (err) {
      console.error('Error processing Shadowsocks JSON:', err.message);
      return res.status(500).json({ 
        status: "error", 
        message: 'Gagal memproses output JSON', 
        raw: output 
      });
    }
  });
});

// ===============================
// Create ZIVPN (FINAL FIX)
// ===============================
app.get('/createzivpn', (req, res) => {
  let { password, exp, iplimit } = req.query;

  // ===============================
  // VALIDASI
  // ===============================
  if (!exp || !iplimit) {
    return res.status(400).json({
      status: 'error',
      message: 'exp dan iplimit diperlukan'
    });
  }

  // password auto kalau kosong
  password = (password && password.trim() !== '') ? password.trim() : 'auto';

  console.log(
    `⚙️ Create ZIVPN | password=${password} | exp=${exp} | iplimit=${iplimit}`
  );

  // ===============================
  // SPAWN LANGSUNG (NO bash -c)
  // ===============================
  const child = spawn(
    '/usr/bin/apicreate-zivpn',
    [password, String(exp), String(iplimit)],
    {
      stdio: ['ignore', 'pipe', 'pipe'],
      timeout: 20000
    }
  );

  let output = '';

  child.stdout.on('data', d => {
    output += d.toString();
  });

  child.stderr.on('data', d => {
    output += d.toString();
  });

  child.on('error', (err) => {
    console.error('❌ spawn error:', err.message);
    return res.status(500).json({
      status: 'error',
      message: 'Gagal menjalankan apicreate-zivpn',
      detail: err.message
    });
  });

  child.on('close', (code) => {
    if (code !== 0) {
      return res.status(500).json({
        status: 'error',
        message: 'apicreate-zivpn exit non-zero',
        exit_code: code,
        raw: output
      });
    }

    try {
      const cleaned = output.trim();
      const json = JSON.parse(cleaned);

      if (json.status !== 'success') {
        return res.status(500).json(json);
      }

      return res.json({
        status: 'success',
        message: 'ZIVPN account successfully created',
        data: json.data
      });

    } catch (e) {
      console.error('❌ JSON parse error:', e.message);
      return res.status(500).json({
        status: 'error',
        message: 'Gagal parse output apicreate-zivpn',
        raw: output,
        detail: e.message
      });
    }
  });
});

// ===============================
// Renew ZIVPN API
// ===============================
app.get('/renewzivpn', (req, res) => {
  const { password, days, iplimit } = req.query;

  if (!password || !days || !iplimit) {
    return res.status(400).json({
      status: 'error',
      message: 'password, days, iplimit diperlukan'
    });
  }

  const child = spawn(
    '/usr/bin/apirenew-zivpn',
    [password, String(days), String(iplimit)],
    { stdio: ['ignore', 'pipe', 'pipe'] }
  );

  let output = '';
  child.stdout.on('data', d => output += d.toString());
  child.stderr.on('data', d => output += d.toString());

  child.on('close', (code) => {
    if (code !== 0) {
      return res.status(500).json({
        status: 'error',
        message: 'apirenew-zivpn gagal',
        raw: output
      });
    }

    try {
      const json = JSON.parse(output.trim());
      return res.json(json);
    } catch (e) {
      return res.status(500).json({
        status: 'error',
        message: 'JSON parse error',
        raw: output
      });
    }
  });
});
// ===============================
// Delete ZIVPN
// ===============================
app.get("/deletezivpn", (req, res) => {
  const { password } = req.query;

  if (!password) {
    return res.status(400).json({
      error: "password diperlukan"
    });
  }

  console.log(`Menerima delete ZIVPN password=${password}`);

  const child = spawn(
    "/bin/bash",
    ["-c", `/usr/bin/apidelete-zivpn ${password}`],
    { stdio: ['pipe','pipe','pipe'] }
  );

  let output = '';
  child.stdout.on('data', d => output += d.toString());
  child.stderr.on('data', d => output += d.toString());

  child.on('close', () => {
    try {
      const cleaned = output
        .replace(/,\s*}/g, '}')
        .replace(/,\s*]/g, ']')
        .trim();

      const json = JSON.parse(cleaned);

      if (json.status !== "success") {
        return res.status(500).json(json);
      }

      return res.json({
        status: "success",
        message: "ZIVPN account deleted",
        data: json.data
      });
    } catch (e) {
      return res.status(500).json({
        error: "Gagal parse output apidelete-zivpn",
        raw: output,
        detail: e.message
      });
    }
  });
});
// ===============================
// Create ZIVPN Trial
// ===============================
app.get("/trialzivpn", (req, res) => {
  console.log(`⚡ Trial ZIVPN request from ${req.ip}`);

  // ===============================
  // FIX: Ambil dari 'duration' (sesuai kiriman bot) atau 'minutes'
  // ===============================
  const minutes = req.query.duration || req.query.minutes || "60"; 
  const iplimit = req.query.iplimit || "2"; 

  // Validasi sederhana: pastikan minutes adalah angka
  const finalMinutes = /^\d+$/.test(minutes) ? minutes : "60";

  // ===============================
  // SPAWN SCRIPT
  // ===============================
  // Pastikan path script benar: /usr/bin/apitrial-zivpn
  const child = spawn(
    "/usr/bin/apitrial-zivpn",
    [String(finalMinutes), String(iplimit)],
    {
      stdio: ['ignore', 'pipe', 'pipe'],
      timeout: 20000
    }
  );

  let output = '';

  child.stdout.on('data', d => {
    output += d.toString();
  });

  child.stderr.on('data', d => {
    // console.error('stderr:', d.toString()); // opsional untuk debug
    output += d.toString();
  });

  child.on('error', err => {
    console.error('❌ spawn error:', err.message);
    if (!res.headersSent) {
        return res.status(500).json({
          status: "error",
          message: "Gagal menjalankan script",
          detail: err.message
        });
    }
  });

  child.on('close', code => {
    if (res.headersSent) return;

    // Jika script keluar dengan error
    if (code !== 0) {
      return res.status(500).json({
        status: "error",
        message: `Script exit code ${code}`,
        raw: output
      });
    }

    try {
      // Membersihkan karakter aneh atau log script bash sebelum di-parse
      const jsonStartIndex = output.indexOf('{');
      const jsonEndIndex = output.lastIndexOf('}') + 1;
      const jsonContent = output.substring(jsonStartIndex, jsonEndIndex);

      const json = JSON.parse(jsonContent);

      // Return hasil ke Bot
      return res.json({
        status: "success",
        message: "ZIVPN trial created",
        data: {
          password: json.data.password,
          ip_limit: json.data.ip_limit || iplimit,
          duration_minutes: json.data.duration_minutes || finalMinutes,
          created: json.data.created,
          expired: json.data.expired
        }
      });

    } catch (err) {
      console.error("❌ JSON parse error:", err.message);
      return res.status(500).json({
        status: "error",
        message: "Output script bukan JSON valid",
        raw: output
      });
    }
  });
});
// --- ENDPOINT LIST MEMBER ---
app.get("/list", (req, res) => {
  const { type } = req.query;

  if (!type) {
    return res.status(400).json({ status: "error", message: 'Parameter type diperlukan' });
  }

  console.log(`🔍 Memproses list untuk protocol: ${type}`);

  // Menggunakan gaya spawn agar sama dengan fungsi renew kamu
  const child = spawn("/bin/bash", ["-c", `/usr/bin/apilist ${type}`], {
    stdio: ['pipe', 'pipe', 'pipe']
  });

  child.stdin.end();

  let output = '';
  let errorOutput = '';

  // Menangkap data sukses
  child.stdout.on('data', (data) => {
    output += data.toString();
  });

  // Menangkap data error
  child.stderr.on('data', (data) => {
    console.error(`stderr: ${data}`);
    errorOutput += data.toString();
  });

  child.on('close', (code) => {
    if (code !== 0) {
      console.log(`❌ Script gagal dengan kode: ${code}`);
      return res.status(500).json({ 
        status: "error", 
        message: 'Gagal eksekusi script list', 
        detail: errorOutput.trim() 
      });
    }

    try {
      // Membersihkan spasi/newline agar tidak error saat parse
      const cleanOutput = output.trim();
      const jsonResponse = JSON.parse(cleanOutput);

      // Kirim hasil ke bot
      res.json(jsonResponse);
      
    } catch (parseError) {
      console.error('❌ Error parsing JSON:', parseError);
      res.status(500).json({ 
        status: "error", 
        message: 'Data dari script bukan JSON valid',
        raw: output 
      });
    }
  });
});

const PORT = process.env.PORT || 5888;
app.listen(PORT, '0.0.0.0', () => {
  console.log(`Server berjalan di port ${PORT}`);
});