const os = require('os');
const { exec, execSync, spawn } = require('child_process');
const express = require('express');
const path = require('path');
const fs = require('fs');

const app = express();

// Middleware untuk memeriksa kata sandi
const checkPassword = (req, res, next) => {
  const { auth } = req.query;
  const correctPassword = fs.readFileSync('/root/.key', 'utf8').trim(); // Membaca kata sandi dari /root/.key
  
  if (auth !== correctPassword) {
    return res.status(401).send('<html><body><h1 style="text-align: center;">Akses Ditolak</h1><p style="text-align: center;">Anda tidak memiliki izin untuk mengakses halaman ini.</p></body></html>');
  }
  
  next();
};

// Terapkan middleware checkPassword ke semua rute
app.use(checkPassword);

// Create ssh user
app.get("/createssh", (req, res) => {
  const { user, password, exp, iplimit } = req.query;
  if (!user || !password || !exp || !iplimit) {
    return res.status(400).json({ error: 'Username, expiry, iplimit, dan password diperlukan' });
  }
  
  console.log(`Menerima permintaan untuk membuat akun SSH dengan user: ${user}, exp: ${exp}, iplimit: ${iplimit}, password: ${password}`);
  
  const child = spawn("/bin/bash", ["-c", `apicreate ssh ${user} ${password} ${exp} ${iplimit}`], {
    stdio: ['pipe', 'pipe', 'pipe']
  });
  
  child.stdin.end();
  let output = '';
  child.stdout.on('data', (data) => {
    output += data.toString();
  });
  
  child.stderr.on('data', (data) => {
    console.error(`Kesalahan: ${data}`);
    output += data.toString();
  });
  
  child.on('close', (code) => {
    if (code !== 0) {
      console.log(`Proses pembuatan akun SSH gagal dengan kode: ${code}`);
      return res.status(500).json({ error: 'Terjadi kesalahan saat membuat akun', detail: output });
    }
    console.log(`Akun SSH berhasil dibuat untuk user: ${user}`);
    
    try {
      const jsonResponse = JSON.parse(output);
      if (jsonResponse.status === "success") {
        res.json({
          status: "success",
          message: "SSH account successfully created",
          data: {
            username: jsonResponse.data.username,
            password: jsonResponse.data.password,
            expired: jsonResponse.data.expired,            
            ip_limit: jsonResponse.data.ip_limit,
            domain: jsonResponse.data.domain,
            ns_domain: jsonResponse.data.ns_domain,
            city: jsonResponse.data.city,
            pubkey: jsonResponse.data.pubkey
          }
        });
      } else {
        res.status(500).json({ error: "Gagal membuat akun SSH", detail: jsonResponse.message });
      }
    } catch (err) {
      console.error(`Kesalahan parsing JSON: ${err}`);
      res.status(500).json({ error: "Terjadi kesalahan saat memproses hasil", detail: err.message });
    }
  });
});

// Create vmess user
app.get("/createvmess", (req, res) => {
  const { user, exp, quota, iplimit } = req.query;
  if (!user || !exp || !quota || !iplimit) {
    return res.status(400).json({ error: 'Username, expiry, quota, dan iplimit diperlukan' });
  }
  
  console.log(`Menerima permintaan untuk membuat akun VMess dengan user: ${user}, exp: ${exp}, quota: ${quota}, iplimit: ${iplimit}`);
  
  const child = spawn("/bin/bash", ["-c", `apicreate vmess ${user} ${exp} ${quota} ${iplimit}`], {
    stdio: ['pipe', 'pipe', 'pipe']
  });
  
  child.stdin.end();
  let output = '';
  child.stdout.on('data', (data) => {
    output += data.toString();
  });
  
  child.stderr.on('data', (data) => {
    console.error(`Kesalahan: ${data}`);
    output += data.toString();
  });
  
  child.on('close', (code) => {
    if (code !== 0) {
      console.log(`Proses pembuatan akun VMess gagal dengan kode: ${code}`);
      return res.status(500).json({ error: 'Terjadi kesalahan saat membuat akun', detail: output });
    }
    console.log(`Akun VMess berhasil dibuat untuk user: ${user}`);
    
    try {
      const jsonResponse = JSON.parse(output);
      if (jsonResponse.status === "success") {
        res.json({
          status: "success",
          message: "Vmess account successfully created",
          data: {
            username: jsonResponse.data.username,
            expired: jsonResponse.data.expired,
            uuid: jsonResponse.data.uuid,
            quota: jsonResponse.data.quota,
            ip_limit: jsonResponse.data.ip_limit,
            domain: jsonResponse.data.domain,
            ns_domain: jsonResponse.data.ns_domain,
            city: jsonResponse.data.city,
            pubkey: jsonResponse.data.pubkey,
            vmess_tls_link: jsonResponse.data.vmess_tls_link,
            vmess_nontls_link: jsonResponse.data.vmess_nontls_link,
            vmess_grpc_link: jsonResponse.data.vmess_grpc_link
          }
        });
      } else {
        res.status(500).json({ error: 'Terjadi kesalahan saat membuat akun', detail: jsonResponse.message });
      }
    } catch (error) {
      console.error('Error parsing JSON:', error);
      res.status(500).json({ error: 'Terjadi kesalahan saat memproses output JSON' });
    }
  });
});


// Create vless user
app.get("/createvless", (req, res) => {
  const { user, exp, quota, iplimit } = req.query;
  if (!user || !exp || !quota || !iplimit) {
    return res.status(400).json({ error: 'Username, expiry, quota, dan iplimit diperlukan' });
  }
  
  console.log(`Menerima permintaan untuk membuat akun VLESS dengan user: ${user}, exp: ${exp}, quota: ${quota}, iplimit: ${iplimit}`);
  
  const child = spawn("/bin/bash", ["-c", `apicreate vless ${user} ${exp} ${quota} ${iplimit}`], {
    stdio: ['pipe', 'pipe', 'pipe']
  });
  
  child.stdin.end();
  let output = '';
  child.stdout.on('data', (data) => {
    output += data.toString();
  });
  
  child.stderr.on('data', (data) => {
    console.error(`Kesalahan: ${data}`);
    output += data.toString();
  });
  
  child.on('close', (code) => {
    if (code !== 0) {
      console.log(`Proses pembuatan akun VLESS gagal dengan kode: ${code}`);
      return res.status(500).json({ error: 'Terjadi kesalahan saat membuat akun', detail: output });
    }
    console.log(`Akun VLESS berhasil dibuat untuk user: ${user}`);
    
    try {
      const jsonResponse = JSON.parse(output);
      if (jsonResponse.status === "success") {
        res.json({
          status: "success",
          message: "VLESS account successfully created",
          data: {
            username: jsonResponse.data.username,
            expired: jsonResponse.data.expired,
            uuid: jsonResponse.data.uuid,
            quota: jsonResponse.data.quota,
            ip_limit: jsonResponse.data.ip_limit,
            domain: jsonResponse.data.domain,
            ns_domain: jsonResponse.data.ns_domain,
            city: jsonResponse.data.city,
            pubkey: jsonResponse.data.pubkey,
            vless_tls_link: jsonResponse.data.vless_tls_link,
            vless_nontls_link: jsonResponse.data.vless_nontls_link,
            vless_grpc_link: jsonResponse.data.vless_grpc_link
          }
        });
      } else {
        res.status(500).json({ error: 'Terjadi kesalahan saat membuat akun', detail: jsonResponse.message });
      }
    } catch (error) {
      console.error('Error parsing JSON:', error);
      res.status(500).json({ error: 'Terjadi kesalahan saat memproses output JSON' });
    }
  });
});

// Create trojan user
app.get("/createtrojan", (req, res) => {
  const { user, exp, quota, iplimit } = req.query;
  if (!user || !exp || !quota || !iplimit) {
    return res.status(400).json({ error: 'Username, expiry, quota, dan iplimit diperlukan' });
  }
  
  console.log(`Menerima permintaan untuk membuat akun Trojan dengan user: ${user}, exp: ${exp}, quota: ${quota}, iplimit: ${iplimit}`);
  
  const child = spawn("/bin/bash", ["-c", `apicreate trojan ${user} ${exp} ${quota} ${iplimit}`], {
    stdio: ['pipe', 'pipe', 'pipe']
  });
  
  child.stdin.end();
  let output = '';
  child.stdout.on('data', (data) => {
    output += data.toString();
  });
  
  child.stderr.on('data', (data) => {
    console.error(`Kesalahan: ${data}`);
    output += data.toString();
  });
  
  child.on('close', (code) => {
    if (code !== 0) {
      console.log(`Proses pembuatan akun Trojan gagal dengan kode: ${code}`);
      return res.status(500).json({ error: 'Terjadi kesalahan saat membuat akun', detail: output });
    }
    console.log(`Akun Trojan berhasil dibuat untuk user: ${user}`);
    
    try {
      const jsonResponse = JSON.parse(output);
      if (jsonResponse.status === "success") {
        res.json({
          status: "success",
          message: "Trojan account successfully created",
          data: {
            username: jsonResponse.data.username,
            expired: jsonResponse.data.expired,
            uuid: jsonResponse.data.uuid,
            quota: jsonResponse.data.quota,
            ip_limit: jsonResponse.data.ip_limit,
            domain: jsonResponse.data.domain,
            ns_domain: jsonResponse.data.ns_domain,
            city: jsonResponse.data.city,
            pubkey: jsonResponse.data.pubkey,
            trojan_tls_link: jsonResponse.data.trojan_tls_link,
            trojan_grpc_link: jsonResponse.data.trojan_grpc_link
          }
        });
      } else {
        res.status(500).json({ error: 'Terjadi kesalahan saat membuat akun', detail: jsonResponse.message });
      }
    } catch (error) {
      console.error('Error parsing JSON:', error);
      res.status(500).json({ error: 'Terjadi kesalahan saat memproses output JSON' });
    }
  });
});


// Create shadowsocks user
app.get("/createshadowsocks", (req, res) => {
  const { user, exp, quota, iplimit } = req.query;
  if (!user || !exp || !quota || !iplimit) {
    return res.status(400).json({ error: 'Username, expiry, quota, dan iplimit diperlukan' });
  }
  
  console.log(`Menerima permintaan untuk membuat akun Shadowsocks dengan user: ${user}, exp: ${exp}, quota: ${quota}, iplimit: ${iplimit}`);
  
  const child = spawn("/bin/bash", ["-c", `apicreate shadowsocks ${user} ${exp} ${quota} ${iplimit}`], {
    stdio: ['pipe', 'pipe', 'pipe']
  });
  
  child.stdin.end();
  let output = '';
  child.stdout.on('data', (data) => {
    output += data.toString();
  });
  
  child.stderr.on('data', (data) => {
    console.error(`Kesalahan: ${data}`);
    output += data.toString();
  });
  
  child.on('close', (code) => {
    if (code !== 0) {
      console.log(`Proses pembuatan akun Shadowsocks gagal dengan kode: ${code}`);
      return res.status(500).json({ error: 'Terjadi kesalahan saat membuat akun', detail: output });
    }
    console.log(`Akun Shadowsocks berhasil dibuat untuk user: ${user}`);
    
    try {
      const jsonResponse = JSON.parse(output);
      if (jsonResponse.status === "success") {
        res.json({
          status: "success",
          message: "Shadowsocks account successfully created",
          data: {
            username: jsonResponse.data.username,
            expired: jsonResponse.data.expired,
            password: jsonResponse.data.password,
            method: jsonResponse.data.method,
            quota: jsonResponse.data.quota,
            ip_limit: jsonResponse.data.ip_limit,
            domain: jsonResponse.data.domain,
            ns_domain: jsonResponse.data.ns_domain,
            city: jsonResponse.data.city,
            pubkey: jsonResponse.data.pubkey,
            ss_link_ws: jsonResponse.data.ss_link_ws,
            ss_link_grpc: jsonResponse.data.ss_link_grpc
          }
        });
      } else {
        res.status(500).json({ error: 'Terjadi kesalahan saat membuat akun', detail: jsonResponse.message });
      }
    } catch (error) {
      console.error('Error parsing JSON:', error);
      res.status(500).json({ error: 'Terjadi kesalahan saat memproses output JSON' });
    }
  });
});
// Check SSH user
app.get("/checkssh", (req, res) => { 
  
  const child = spawn("/bin/bash", ["-c", `apicheck ssh`], {
    stdio: ['pipe', 'pipe', 'pipe']
  });
  
  child.stdin.end();
  let output = '';
  child.stdout.on('data', (data) => {
    output += data.toString();
  });
  
  child.stderr.on('data', (data) => {
    console.error(`Kesalahan: ${data}`);
    output += data.toString();
  });
  
  child.on('close', (code) => {
    if (code !== 0) {
      console.log(`Proses pemeriksaan akun SSH gagal dengan kode: ${code}`);
      return res.status(500).json({ error: 'Terjadi kesalahan saat memeriksa akun', detail: output });
    }
    console.log(`Akun SSH berhasil diperiksa`);
    try {
      // Menghapus koma ekstra sebelum mem-parsing JSON
      const cleanedOutput = output.replace(/,\s*}/g, '}').replace(/,\s*]/g, ']');
      const jsonResponse = JSON.parse(cleanedOutput);
      if (jsonResponse.status === "success" && jsonResponse.data) {
        res.json({
          status: "success",
          message: jsonResponse.data.message,
          data: jsonResponse.data
        });
      } else {
        res.status(404).json({ error: 'Akun SSH tidak ditemukan' });
      }
    } catch (error) {
      console.error(`Error parsing JSON: ${error}`);
      res.status(500).json({ error: 'Terjadi kesalahan saat memproses output JSON' });
    }
  });
});

app.get("/checkvmess", (req, res) => { 

  console.log(`Menerima permintaan untuk memeriksa akun VMess dengan user: `);
  
  const child = spawn("/bin/bash", ["-c", `apicheck vmess`], {
    stdio: ['pipe', 'pipe', 'pipe']
  });
  
  child.stdin.end();
  let output = '';
  child.stdout.on('data', (data) => {
    output += data.toString();
  });
  
  child.stderr.on('data', (data) => {
    console.error(`Kesalahan: ${data}`);
    output += data.toString();
  });
  
  child.on('close', (code) => {
    if (code !== 0) {
      console.log(`Proses pemeriksaan akun VMess gagal dengan kode: ${code}`);
      return res.status(500).json({ error: 'Terjadi kesalahan saat memeriksa akun', detail: output });
    }
    console.log(`Akun VMess berhasil diperiksa`);
    
    try {
      // Menghapus koma ekstra sebelum mem-parsing JSON
      const cleanedOutput = output.replace(/,\s*}/g, '}').replace(/,\s*]/g, ']');
      const jsonResponse = JSON.parse(cleanedOutput);
      if (jsonResponse.status === "success" && jsonResponse.data) {
        res.json({
          status: "success",
          message: jsonResponse.data.message,
          data: jsonResponse.data
        });
      } else {
        res.status(404).json({ error: 'Akun VMess tidak ditemukan' });
      }
    } catch (error) {
      console.error('Error parsing JSON:', error);
      res.status(500).json({ error: 'Terjadi kesalahan saat memproses output JSON' });
    }
  });
});
app.get("/checkvless", (req, res) => { 

  console.log(`Menerima permintaan untuk memeriksa akun VLESS dengan user: `);
  
  const child = spawn("/bin/bash", ["-c", `apicheck vless`], {
    stdio: ['pipe', 'pipe', 'pipe']
  });
  
  child.stdin.end();
  let output = '';
  child.stdout.on('data', (data) => {
    output += data.toString();
  });
  
  child.stderr.on('data', (data) => {
    console.error(`Kesalahan: ${data}`);
    output += data.toString();
  });
  
  child.on('close', (code) => {
    if (code !== 0) {
      console.log(`Proses pemeriksaan akun VLESS gagal dengan kode: ${code}`);
      return res.status(500).json({ error: 'Terjadi kesalahan saat memeriksa akun', detail: output });
    }
    console.log(`Akun VLESS berhasil diperiksa`);
    
    try {
      // Menghapus koma ekstra sebelum mem-parsing JSON
      const cleanedOutput = output.replace(/,\s*}/g, '}').replace(/,\s*]/g, ']');
      const jsonResponse = JSON.parse(cleanedOutput);
      if (jsonResponse.status === "success" && jsonResponse.data) {
        res.json({
          status: "success",
          message: jsonResponse.data.message,
          data: jsonResponse.data
        });
      } else {
        res.status(404).json({ error: 'Akun VLESS tidak ditemukan' });
      }
    } catch (error) {
      console.error('Error parsing JSON:', error);
      res.status(500).json({ error: 'Terjadi kesalahan saat memproses output JSON' });
    }
  });
});

app.get("/checktrojan", (req, res) => { 

  console.log(`Menerima permintaan untuk memeriksa akun Trojan dengan user: `);
  
  const child = spawn("/bin/bash", ["-c", `apicheck trojan`], {
    stdio: ['pipe', 'pipe', 'pipe']
  });
  
  child.stdin.end();
  let output = '';
  child.stdout.on('data', (data) => {
    output += data.toString();
  });
  
  child.stderr.on('data', (data) => {
    console.error(`Kesalahan: ${data}`);
    output += data.toString();
  });
  
  child.on('close', (code) => {
    if (code !== 0) {
      console.log(`Proses pemeriksaan akun Trojan gagal dengan kode: ${code}`);
      return res.status(500).json({ error: 'Terjadi kesalahan saat memeriksa akun', detail: output });
    }
    console.log(`Akun Trojan berhasil diperiksa`);
    
    try {
      // Menghapus koma ekstra sebelum mem-parsing JSON
      const cleanedOutput = output.replace(/,\s*}/g, '}').replace(/,\s*]/g, ']');
      const jsonResponse = JSON.parse(cleanedOutput);
      if (jsonResponse.status === "success" && jsonResponse.data) {
        res.json({
          status: "success",
          message: jsonResponse.data.message,
          data: jsonResponse.data
        });
      } else {
        res.status(404).json({ error: 'Akun Trojan tidak ditemukan' });
      }
    } catch (error) {
      console.error('Error parsing JSON:', error);
      res.status(500).json({ error: 'Terjadi kesalahan saat memproses output JSON' });
    }
  });
});

app.get("/checkshadowsocks", (req, res) => { 

  console.log(`Menerima permintaan untuk memeriksa akun Shadowsocks dengan user: `);
  
  const child = spawn("/bin/bash", ["-c", `apicheck shadowsocks`], {
    stdio: ['pipe', 'pipe', 'pipe']
  });
  
  child.stdin.end();
  let output = '';
  child.stdout.on('data', (data) => {
    output += data.toString();
  });
  
  child.stderr.on('data', (data) => {
    console.error(`Kesalahan: ${data}`);
    output += data.toString();
  });
  
  child.on('close', (code) => {
    if (code !== 0) {
      console.log(`Proses pemeriksaan akun Shadowsocks gagal dengan kode: ${code}`);
      return res.status(500).json({ error: 'Terjadi kesalahan saat memeriksa akun', detail: output });
    }
    console.log(`Akun Shadowsocks berhasil diperiksa`);
    
    try {
      // Menghapus koma ekstra sebelum mem-parsing JSON
      const cleanedOutput = output.replace(/,\s*}/g, '}').replace(/,\s*]/g, ']');
      const jsonResponse = JSON.parse(cleanedOutput);
      if (jsonResponse.status === "success" && jsonResponse.data) {
        res.json({
          status: "success",
          message: jsonResponse.data.message,
          data: jsonResponse.data
        });
      } else {
        res.status(404).json({ error: 'Akun Shadowsocks tidak ditemukan' });
      }
    } catch (error) {
      console.error('Error parsing JSON:', error);
      res.status(500).json({ error: 'Terjadi kesalahan saat memproses output JSON' });
    }
  });
});

// delete user ssh
app.get("/deletessh", (req, res) => {
  const { user } = req.query;
  if (!user) {
    return res.status(400).json({ error: 'Username diperlukan' });
  }
  
  console.log(`Menerima permintaan untuk menghapus akun SSH dengan user: ${user}`);
  
  const child = spawn("/bin/bash", ["-c", `apidelete ssh ${user}`], {
    stdio: ['pipe', 'pipe', 'pipe']
  });
  
  child.stdin.end();
  let output = '';
  child.stdout.on('data', (data) => {
    output += data.toString();
  });
  
  child.stderr.on('data', (data) => {
    console.error(`Kesalahan: ${data}`);
    output += data.toString();
  });
  
  child.on('close', (code) => {
    if (code !== 0) {
      console.log(`Proses penghapusan akun SSH gagal dengan kode: ${code}`);
      return res.status(500).json({ error: 'Terjadi kesalahan saat menghapus akun', detail: output });
    }
    console.log(`Akun SSH berhasil dihapus untuk user: ${user}`);
    
    try {
      // Menghapus koma ekstra sebelum mem-parsing JSON
      const cleanedOutput = output.replace(/,\s*}/g, '}').replace(/,\s*]/g, ']');
      const jsonResponse = JSON.parse(cleanedOutput);
      if (jsonResponse.status === "success" && jsonResponse.data) {
        res.json({
          status: "success",
          message: jsonResponse.data.message,
          data: jsonResponse.data
        });
      } else {
        res.status(404).json({ error: 'Akun SSH tidak ditemukan' });
      }
    } catch (error) {
      console.error('Error parsing JSON:', error);
      res.status(500).json({ error: 'Terjadi kesalahan saat memproses output JSON' });
    }
  });
});
// delete user vmess
app.get("/deletevmess", (req, res) => {
  const { user } = req.query;
  if (!user) {
    return res.status(400).json({ error: 'Username diperlukan' });
  }
  
  console.log(`Menerima permintaan untuk menghapus akun VMess dengan user: ${user}`);
  
  const child = spawn("/bin/bash", ["-c", `apidelete vmess ${user}`], {
    stdio: ['pipe', 'pipe', 'pipe']
  });
  
  child.stdin.end();
  let output = '';
  child.stdout.on('data', (data) => {
    output += data.toString();
  });
  
  child.stderr.on('data', (data) => {
    console.error(`Kesalahan: ${data}`);
    output += data.toString();
  });
  
  child.on('close', (code) => {
    if (code !== 0) {
      console.log(`Proses penghapusan akun VMess gagal dengan kode: ${code}`);
      return res.status(500).json({ error: 'Terjadi kesalahan saat menghapus akun', detail: output });
    }
    console.log(`Akun VMess berhasil dihapus untuk user: ${user}`);
    
      // Menghapus koma ekstra sebelum mem-parsing JSON
      try {
        const cleanedOutput = output.replace(/,\s*}/g, '}').replace(/,\s*]/g, ']');
        const jsonResponse = JSON.parse(cleanedOutput);
        if (jsonResponse.status === "success" && jsonResponse.data) {
          res.json({
            status: "success",
            message: jsonResponse.data.message,
            data: jsonResponse.data
          });
        } else {
          res.status(404).json({ error: 'Akun VMess tidak ditemukan' });
        }
      } catch (error) {
        console.error('Error parsing JSON:', error);
        res.status(500).json({ error: 'Terjadi kesalahan saat memproses output JSON' });
      }
    });
});

// delete user vless
app.get("/deletevless", (req, res) => {
  const { user } = req.query;
  if (!user) {
    return res.status(400).json({ error: 'Username diperlukan' });
  }
  
  console.log(`Menerima permintaan untuk menghapus akun VLess dengan user: ${user}`);
  
  const child = spawn("/bin/bash", ["-c", `apidelete vless ${user}`], {
    stdio: ['pipe', 'pipe', 'pipe']
  });
  
  child.stdin.end();
  let output = '';
  child.stdout.on('data', (data) => {
    output += data.toString();
  });
  
  child.stderr.on('data', (data) => {
    console.error(`Kesalahan: ${data}`);
    output += data.toString();
  });
  
  child.on('close', (code) => {
    if (code !== 0) {
      console.log(`Proses penghapusan akun VLess gagal dengan kode: ${code}`);
      return res.status(500).json({ error: 'Terjadi kesalahan saat menghapus akun', detail: output });
    }
    console.log(`Akun VLess berhasil dihapus untuk user: ${user}`);
    
    
    try {
      const cleanedOutput = output.replace(/,\s*}/g, '}').replace(/,\s*]/g, ']');
      const jsonResponse = JSON.parse(cleanedOutput);
      if (jsonResponse.status === "success" && jsonResponse.data) {
        res.json({
          status: "success",
          message: jsonResponse.data.message,
          data: jsonResponse.data
        });
      } else {
        res.status(404).json({ error: 'Akun VLess tidak ditemukan' });
      }
    } catch (error) {
      console.error('Error parsing JSON:', error);
      res.status(500).json({ error: 'Terjadi kesalahan saat memproses output JSON' });
    }
  });
});
// delete user trojan
app.get("/deletetrojan", (req, res) => {
  const { user } = req.query;
  if (!user) {
    return res.status(400).json({ error: 'Username diperlukan' });
  }
  
  console.log(`Menerima permintaan untuk menghapus akun Trojan dengan user: ${user}`);
  
  const child = spawn("/bin/bash", ["-c", `apidelete trojan ${user}`], {
    stdio: ['pipe', 'pipe', 'pipe']
  });
  
  child.stdin.end();
  let output = '';
  child.stdout.on('data', (data) => {
    output += data.toString();
  });
  
  child.stderr.on('data', (data) => {
    console.error(`Kesalahan: ${data}`);
    output += data.toString();
  });
  
  child.on('close', (code) => {
    if (code !== 0) {
      console.log(`Proses penghapusan akun Trojan gagal dengan kode: ${code}`);
      return res.status(500).json({ error: 'Terjadi kesalahan saat menghapus akun', detail: output });
    }
    console.log(`Akun Trojan berhasil dihapus untuk user: ${user}`);
    
    
    try {
      const cleanedOutput = output.replace(/,\s*}/g, '}').replace(/,\s*]/g, ']');
      const jsonResponse = JSON.parse(cleanedOutput);
      if (jsonResponse.status === "success" && jsonResponse.data) {
        res.json({
          status: "success",
          message: jsonResponse.data.message,
          data: jsonResponse.data
        });
      } else {
        res.status(404).json({ error: 'Akun Trojan tidak ditemukan' });
      }
    } catch (error) {
      console.error('Error parsing JSON:', error);
      res.status(500).json({ error: 'Terjadi kesalahan saat memproses output JSON' });
    }
  });
});
// delete user shadowsocks
app.get("/deleteshadowsocks", (req, res) => {
  const { user } = req.query;
  if (!user) {
    return res.status(400).json({ error: 'Username diperlukan' });
  }
  
  console.log(`Menerima permintaan untuk menghapus akun Shadowsocks dengan user: ${user}`);
  
  const child = spawn("/bin/bash", ["-c", `apidelete shadowsocks ${user}`], {
    stdio: ['pipe', 'pipe', 'pipe']
  });
  
  child.stdin.end();
  let output = '';
  child.stdout.on('data', (data) => {
    output += data.toString();
  });
  
  child.stderr.on('data', (data) => {
    console.error(`Kesalahan: ${data}`);
    output += data.toString();
  });
  
  child.on('close', (code) => {
    if (code !== 0) {
      console.log(`Proses penghapusan akun Shadowsocks gagal dengan kode: ${code}`);
      return res.status(500).json({ error: 'Terjadi kesalahan saat menghapus akun', detail: output });
    }
    console.log(`Akun Shadowsocks berhasil dihapus untuk user: ${user}`);
    
    try {
      const cleanedOutput = output.replace(/,\s*}/g, '}').replace(/,\s*]/g, ']');
      const jsonResponse = JSON.parse(cleanedOutput);
      if (jsonResponse.status === "success" && jsonResponse.data) {
        res.json({
          status: "success",
          message: jsonResponse.data.message,
          data: jsonResponse.data
        });
      } else {
        res.status(404).json({ error: 'Akun Shadowsocks tidak ditemukan' });
      }
    } catch (error) {
      console.error('Error parsing JSON:', error);
      res.status(500).json({ error: 'Terjadi kesalahan saat memproses output JSON' });
    }
  });
});
// Renew ssh user
app.get("/renewssh", (req, res) => {
  const { user, exp, iplimit } = req.query;
  if (!user || !exp || !iplimit) {
    return res.status(400).json({ error: 'Username, expiry, dan iplimit diperlukan' });
  }
  
  console.log(`Menerima permintaan untuk memperbarui akun SSH dengan user: ${user}, exp: ${exp}, iplimit: ${iplimit}`);
  
  const child = spawn("/bin/bash", ["-c", `apirenew ssh ${user} ${exp} ${iplimit}`], {
    stdio: ['pipe', 'pipe', 'pipe']
  });
  
  child.stdin.end();
  let output = '';
  child.stdout.on('data', (data) => {
    output += data.toString();
  });
  
  child.stderr.on('data', (data) => {
    console.error(`Kesalahan: ${data}`);
    output += data.toString();
  });
  
  child.on('close', (code) => {
    if (code !== 0) {
      console.log(`Proses pembaruan akun SSH gagal dengan kode: ${code}`);
      return res.status(500).json({ error: 'Terjadi kesalahan saat memperbarui akun', detail: output });
    }
    console.log(`Akun SSH berhasil diperbarui untuk user: ${user}`);
    try {
      const jsonResponse = JSON.parse(output);
      if (jsonResponse.status === "success") {
        res.json({
          status: "success",
          message: "Akun Vmess test berhasil diperbarui",
          data: {
            username: jsonResponse.data.username,
            exp: jsonResponse.data.exp,
            limitip: jsonResponse.data.limitip
          }
        });
      } else {
        res.status(500).json({ error: 'Terjadi kesalahan saat memperbarui akun', detail: jsonResponse.message });
      }
    } catch (error) {
      console.error('Error parsing JSON:', error);
      res.status(500).json({ error: 'Terjadi kesalahan saat memproses output JSON' });
    }
  });
});
// Renew vmess user
app.get("/renewvmess", (req, res) => {
  const { user, exp, quota, iplimit } = req.query;
  if (!user || !exp || !quota || !iplimit) {
    return res.status(400).json({ error: 'Username, expiry, quota, dan iplimit diperlukan' });
  }
  
  console.log(`Menerima permintaan untuk memperbarui akun VMess dengan user: ${user}, exp: ${exp}, quota: ${quota}, iplimit: ${iplimit}`);
  
  const child = spawn("/bin/bash", ["-c", `apirenew vmess ${user} ${exp} ${quota} ${iplimit}`], {
    stdio: ['pipe', 'pipe', 'pipe']
  });
  
  child.stdin.end();
  let output = '';
  child.stdout.on('data', (data) => {
    output += data.toString();
  });
  
  child.stderr.on('data', (data) => {
    console.error(`Kesalahan: ${data}`);
    output += data.toString();
  });
  
  child.on('close', (code) => {
    if (code !== 0) {
      console.log(`Proses pembaruan akun VMess gagal dengan kode: ${code}`);
      return res.status(500).json({ error: 'Terjadi kesalahan saat memperbarui akun', detail: output });
    }
    console.log(`Akun VMess berhasil diperbarui untuk user: ${user}`);
    try {
      const jsonResponse = JSON.parse(output);
      if (jsonResponse.status === "success") {
        res.json({
          status: "success",
          message: "Akun Vmess test berhasil diperbarui",
          data: {
            username: jsonResponse.data.username,
            exp: jsonResponse.data.exp,
            quota: jsonResponse.data.quota,
            limitip: jsonResponse.data.limitip
          }
        });
      } else {
        res.status(500).json({ error: 'Terjadi kesalahan saat memperbarui akun', detail: jsonResponse.message });
      }
    } catch (error) {
      console.error('Error parsing JSON:', error);
      res.status(500).json({ error: 'Terjadi kesalahan saat memproses output JSON' });
    }
  });
});

// Renew vless user
app.get("/renewvless", (req, res) => {
  const { user, exp, quota, iplimit } = req.query;
  if (!user || !exp || !quota || !iplimit) {
    return res.status(400).json({ error: 'Username, expiry, quota, dan iplimit diperlukan' });
  }
  
  console.log(`Menerima permintaan untuk memperbarui akun VLess dengan user: ${user}, exp: ${exp}, quota: ${quota}, iplimit: ${iplimit}`);
  
  const child = spawn("/bin/bash", ["-c", `apirenew vless ${user} ${exp} ${quota} ${iplimit}`], {
    stdio: ['pipe', 'pipe', 'pipe']
  });
  
  child.stdin.end();
  let output = '';
  child.stdout.on('data', (data) => {
    output += data.toString();
  });
  
  child.stderr.on('data', (data) => {
    console.error(`Kesalahan: ${data}`);
    output += data.toString();
  });
  
  child.on('close', (code) => {
    if (code !== 0) {
      console.log(`Proses pembaruan akun VLess gagal dengan kode: ${code}`);
      return res.status(500).json({ error: 'Terjadi kesalahan saat memperbarui akun', detail: output });
    }
    console.log(`Akun VLess berhasil diperbarui untuk user: ${user}`);
    
    try {
      const jsonResponse = JSON.parse(output);
      if (jsonResponse.status === "success") {
        res.json({
          status: "success",
          message: "Akun Vmess test berhasil diperbarui",
          data: {
            username: jsonResponse.data.username,
            exp: jsonResponse.data.exp,
            quota: jsonResponse.data.quota,
            limitip: jsonResponse.data.limitip
          }
        });
      } else {
        res.status(500).json({ error: 'Terjadi kesalahan saat memperbarui akun', detail: jsonResponse.message });
      }
    } catch (error) {
      console.error('Error parsing JSON:', error);
      res.status(500).json({ error: 'Terjadi kesalahan saat memproses output JSON' });
    }
  });
});

// Renew trojan user
app.get("/renewtrojan", (req, res) => {
  const { user, exp, quota, iplimit } = req.query;
  if (!user || !exp || !quota || !iplimit) {
    return res.status(400).json({ error: 'Username, expiry, quota, dan iplimit diperlukan' });
  }
  
  console.log(`Menerima permintaan untuk memperbarui akun Trojan dengan user: ${user}, exp: ${exp}, quota: ${quota}, iplimit: ${iplimit}`);
  
  const child = spawn("/bin/bash", ["-c", `apirenew trojan ${user} ${exp} ${quota} ${iplimit}`], {
    stdio: ['pipe', 'pipe', 'pipe']
  });
  
  child.stdin.end();
  let output = '';
  child.stdout.on('data', (data) => {
    output += data.toString();
  });
  
  child.stderr.on('data', (data) => {
    console.error(`Kesalahan: ${data}`);
    output += data.toString();
  });
  
  child.on('close', (code) => {
    if (code !== 0) {
      console.log(`Proses pembaruan akun Trojan gagal dengan kode: ${code}`);
      return res.status(500).json({ error: 'Terjadi kesalahan saat memperbarui akun', detail: output });
    }
    console.log(`Akun Trojan berhasil diperbarui untuk user: ${user}`);
    
    try {
      const jsonResponse = JSON.parse(output);
      if (jsonResponse.status === "success") {
        res.json({
          status: "success",
          message: "Akun Vmess test berhasil diperbarui",
          data: {
            username: jsonResponse.data.username,
            exp: jsonResponse.data.exp,
            quota: jsonResponse.data.quota,
            limitip: jsonResponse.data.limitip
          }
        });
      } else {
        res.status(500).json({ error: 'Terjadi kesalahan saat memperbarui akun', detail: jsonResponse.message });
      }
    } catch (error) {
      console.error('Error parsing JSON:', error);
      res.status(500).json({ error: 'Terjadi kesalahan saat memproses output JSON' });
    }
  });
});

// Renew shadowsocks user
app.get("/renewshadowsocks", (req, res) => {
  const { user, exp, quota, iplimit } = req.query;
  if (!user || !exp || !quota || !iplimit) {
    return res.status(400).json({ error: 'Username, expiry, quota, dan iplimit diperlukan' });
  }
  
  console.log(`Menerima permintaan untuk memperbarui akun Shadowsocks dengan user: ${user}, exp: ${exp}, quota: ${quota}, iplimit: ${iplimit}`);
  
  const child = spawn("/bin/bash", ["-c", `apirenew shadowsocks ${user} ${exp} ${quota} ${iplimit}`], {
    stdio: ['pipe', 'pipe', 'pipe']
  });
  
  child.stdin.end();
  let output = '';
  child.stdout.on('data', (data) => {
    output += data.toString();
  });
  
  child.stderr.on('data', (data) => {
    console.error(`Kesalahan: ${data}`);
    output += data.toString();
  });
  
  child.on('close', (code) => {
    if (code !== 0) {
      console.log(`Proses pembaruan akun Shadowsocks gagal dengan kode: ${code}`);
      return res.status(500).json({ error: 'Terjadi kesalahan saat memperbarui akun', detail: output });
    }
    console.log(`Akun Shadowsocks berhasil diperbarui untuk user: ${user}`);
    
    try {
      const jsonResponse = JSON.parse(output);
      if (jsonResponse.status === "success") {
        res.json({
          status: "success",
          message: "Akun Vmess test berhasil diperbarui",
          data: {
            username: jsonResponse.data.username,
            exp: jsonResponse.data.exp,
            quota: jsonResponse.data.quota,
            limitip: jsonResponse.data.limitip
          }
        });
      } else {
        res.status(500).json({ error: 'Terjadi kesalahan saat memperbarui akun', detail: jsonResponse.message });
      }
    } catch (error) {
      console.error('Error parsing JSON:', error);
      res.status(500).json({ error: 'Terjadi kesalahan saat memproses output JSON' });
    }
  });
});
// Create SSH trial (for the new api2trial-ssh that returns JSON with ports object)
app.get("/trialssh", (req, res) => {
  // tetap pakai auth middleware yang lo punya (checkPassword)
  console.log(`Menerima permintaan trial SSH (new script) from ${req.ip}`);

  // jalankan script tanpa argumen (script lo menggunakan internal default duration=60)
  const cmd = "/usr/bin/api2trial-ssh";

  const child = spawn("/bin/bash", ["-c", cmd], {
    stdio: ['pipe', 'pipe', 'pipe']
  });

  child.stdin.end();
  let output = '';
  child.stdout.on('data', (data) => {
    output += data.toString();
  });

  child.stderr.on('data', (data) => {
    console.error(`apitrial-ssh stderr: ${data}`);
    output += data.toString();
  });

  child.on('close', (code) => {
    if (code !== 0) {
      console.log(`apitrial-ssh exited with code ${code}`);
      return res.status(500).json({ error: 'Terjadi kesalahan saat membuat trial SSH', detail: output });
    }

    try {
      // lindungi dari trailing commas (sama pattern yang lo pake di route lain)
      const cleanedOutput = output.replace(/,\s*}/g, '}').replace(/,\s*]/g, ']');

      const jsonResponse = JSON.parse(cleanedOutput);

      if (!jsonResponse || jsonResponse.status !== "success") {
        return res.status(500).json({ error: 'apitrial-ssh returned failure', detail: jsonResponse || cleanedOutput });
      }

      // ambil fields penting (ada fallback kalau field tidak ada)
      const data = {
        username: jsonResponse.username || null,
        password: jsonResponse.password || null,
        ip: jsonResponse.ip || null,
        domain: jsonResponse.domain || null,
        city: jsonResponse.city || null,
        ns_domain: jsonResponse.ns_domain || null,
        public_key: jsonResponse.public_key || null,
        expiration: jsonResponse.expiration || null,
        ports: jsonResponse.ports || null,        // object
        openvpn_link: jsonResponse.openvpn_link || null,
        save_link: jsonResponse.save_link || null,
        wss_payload: jsonResponse.wss_payload || null
      };

      return res.json({
        status: "success",
        message: "SSH trial successfully created",
        data
      });
    } catch (err) {
      console.error('Error parsing apitrial-ssh JSON:', err, 'rawOutput:', output);
      return res.status(500).json({ error: 'Terjadi kesalahan saat memproses output JSON', detail: err.message, raw: output });
    }
  });
});

// Create VMess trial (calls /usr/bin/api2trial-vmess)
app.get("/trialvmess", (req, res) => {
  console.log(`Menerima permintaan trial VMess dari ${req.ip}`);

  // jalankan script vmess trial (script lo pake default duration=60)
  const cmd = "/usr/bin/api2trial-vmess";

  const child = spawn("/bin/bash", ["-c", cmd], {
    stdio: ['pipe', 'pipe', 'pipe']
  });

  child.stdin.end();
  let output = '';
  child.stdout.on('data', (data) => {
    output += data.toString();
  });

  child.stderr.on('data', (data) => {
    console.error(`apitrial-vmess stderr: ${data}`);
    output += data.toString();
  });

  child.on('close', (code) => {
    if (code !== 0) {
      console.log(`apitrial-vmess exited with code ${code}`);
      return res.status(500).json({ error: 'Terjadi kesalahan saat membuat trial VMess', detail: output });
    }

    try {
      // bersihkan trailing commas sesuai pola di file lo
      const cleanedOutput = output.replace(/,\s*}/g, '}').replace(/,\s*]/g, ']');
      const jsonResponse = JSON.parse(cleanedOutput);

      if (!jsonResponse || jsonResponse.status !== "success") {
        return res.status(500).json({ error: 'apitrial-vmess returned failure', detail: jsonResponse || cleanedOutput });
      }

      // Ambil fields yang umum ada di script lo
      const data = {
        username: jsonResponse.username || null,
        uuid: jsonResponse.uuid || null,
        ip: jsonResponse.ip || null,
        domain: jsonResponse.domain || null,
        city: jsonResponse.city || null,
        ns_domain: jsonResponse.ns_domain || null,
        public_key: jsonResponse.public_key || null,
        expiration: jsonResponse.expiration || jsonResponse.exp || null,
        protocol: jsonResponse.protocol || 'vmess',
        link_tls: jsonResponse.link_tls || jsonResponse.link_tls || jsonResponse.link_tls || jsonResponse.link_tls || jsonResponse.link_tls || jsonResponse.link_tls || jsonResponse.link_tls || jsonResponse.link_tls || jsonResponse.link_tls || jsonResponse.link_tls || jsonResponse.link_tls || jsonResponse.link_tls || jsonResponse.link_tls || jsonResponse.link_tls || jsonResponse.link_tls || jsonResponse.link_tls || jsonResponse.link_tls || jsonResponse.link_tls || jsonResponse.link_tls || null,
        link_ntls: jsonResponse.link_ntls || jsonResponse.link_ntls || null,
        link_grpc: jsonResponse.link_grpc || jsonResponse.link_grpc || null,
        link_tls_alt: jsonResponse.link_tls || jsonResponse.link_tls || null,
        port_tls: jsonResponse.port_tls || jsonResponse.port_tls || null,
        port_http: jsonResponse.port_http || jsonResponse.port_http || null,
        dns_port: jsonResponse.dns_port || jsonResponse.dns_port || null,
        grpc_port: jsonResponse.grpc_port || jsonResponse.grpc_port || null,
        alter_id: jsonResponse.alter_id || null,
        path: jsonResponse.path || null,
        service_name: jsonResponse.service_name || null
      };

      // Bersihin duplikasi null keys (opsional) — tetap kembalikan apa adanya supaya debugging gampang
      return res.json({
        status: "success",
        message: "VMess trial successfully created",
        data
      });
    } catch (err) {
      console.error('Error parsing apitrial-vmess JSON:', err, 'rawOutput:', output);
      return res.status(500).json({ error: 'Terjadi kesalahan saat memproses output JSON', detail: err.message, raw: output });
    }
  });
});

// Create VLESS trial (calls /usr/bin/api2trial-vless) — robust + normalized output
app.get("/trialvless", (req, res) => {
  console.log(`Menerima permintaan trial VLESS dari ${req.ip}`);

  const cmd = "/usr/bin/api2trial-vless";
  const child = spawn("/bin/bash", ["-c", cmd], { stdio: ['pipe','pipe','pipe'] });

  child.stdin.end();
  let output = '';
  child.stdout.on('data', (data) => { output += data.toString(); });
  child.stderr.on('data', (data) => {
    console.error(`apitrial-vless stderr: ${data}`);
    output += data.toString();
  });

  child.on('close', (code) => {
    if (code !== 0) {
      console.log(`apitrial-vless exited with code ${code}`);
      return res.status(500).json({ error: 'Terjadi kesalahan saat membuat trial VLESS', detail: output });
    }

    try {
      // cleanup: remove null bytes, trim, remove trailing commas like other routes
      let cleanedOutput = String(output).replace(/\u0000/g, '').trim();
      cleanedOutput = cleanedOutput.replace(/,\s*}/g, '}').replace(/,\s*]/g, ']');

      let jsonResponse;
      try {
        jsonResponse = JSON.parse(cleanedOutput);
      } catch (parseErr) {
        console.error('Failed to JSON.parse apitrial-vless output:', parseErr, 'snippet:', cleanedOutput.slice(0,4000));
        return res.status(500).json({ error: 'Gagal parse JSON dari script', detail: parseErr.message, raw: cleanedOutput.slice(0,4000) });
      }

      if (!jsonResponse || jsonResponse.status !== "success") {
        return res.status(500).json({ error: 'api2trial-vless returned failure', detail: jsonResponse || cleanedOutput });
      }

      // normalize fields
      const username   = jsonResponse.username || null;
      const uuid       = jsonResponse.uuid || null;
      const ip         = jsonResponse.ip || null;
      const domain     = jsonResponse.domain || null;
      const ns_domain  = jsonResponse.ns_domain || null;
      const city       = jsonResponse.city || null;
      const public_key = jsonResponse.public_key || null;
      const expiration = jsonResponse.expiration || jsonResponse.exp || null;

      // links: add generic 'link' fallback pointing to TLS link for compatibility
      const link_tls  = jsonResponse.link_tls  || null;
      const link_ntls = jsonResponse.link_ntls || null;
      const link_grpc = jsonResponse.link_grpc || null;
      const link_any  = link_tls || link_ntls || link_grpc || null;

      // build ports object for d.ports compatibility
      const ports = {};
      if (jsonResponse.port_tls)  ports.ssl_tls = String(jsonResponse.port_tls);
      if (jsonResponse.port_http) ports.http    = String(jsonResponse.port_http);
      if (jsonResponse.dns_port)  ports.dns     = String(jsonResponse.dns_port);
      if (jsonResponse.grpc_port) ports.grpc    = String(jsonResponse.grpc_port);
      const portsObj = Object.keys(ports).length ? ports : null;

      const data = {
        username: username,
        uuid: uuid,
        ip: ip,
        domain: domain,
        ns_domain: ns_domain,
        city: city,
        public_key: public_key,
        expiration: expiration,
        protocol: jsonResponse.protocol || 'vless',
        // links
        link: link_any,
        link_tls: link_tls,
        link_ntls: link_ntls,
        link_grpc: link_grpc,
        // ports/raw fields (keep both for compatibility)
        port_tls: jsonResponse.port_tls || null,
        port_http: jsonResponse.port_http || null,
        dns_port: jsonResponse.dns_port || null,
        grpc_port: jsonResponse.grpc_port || null,
        // convenience ports object
        ports: portsObj,
        // other metadata
        path: jsonResponse.path || null,
        service_name: jsonResponse.service_name || null
      };

      return res.json({
        status: "success",
        message: "VLESS trial successfully created",
        data
      });
    } catch (err) {
      console.error('Error processing api2trial-vless output:', err, 'rawOutputSlice:', output.slice(0,4000));
      return res.status(500).json({ error: 'Terjadi kesalahan saat memproses output JSON', detail: err.message, raw: output.slice(0,4000) });
    }
  });
});

// Create Trojan trial (calls /usr/bin/api2trial-trojan)
app.get("/trialtrojan", (req, res) => {
  console.log(`Menerima permintaan trial Trojan dari ${req.ip}`);

  // jalankan script trojan trial (script lo pake default duration=60)
  const cmd = "/usr/bin/api2trial-trojan";

  const child = spawn("/bin/bash", ["-c", cmd], {
    stdio: ['pipe', 'pipe', 'pipe']
  });

  child.stdin.end();
  let output = '';
  child.stdout.on('data', (data) => {
    output += data.toString();
  });

  child.stderr.on('data', (data) => {
    console.error(`apitrial-trojan stderr: ${data}`);
    output += data.toString();
  });

  child.on('close', (code) => {
    if (code !== 0) {
      console.log(`apitrial-trojan exited with code ${code}`);
      return res.status(500).json({ error: 'Terjadi kesalahan saat membuat trial Trojan', detail: output });
    }

    try {
      // bersihkan trailing commas sesuai pola yang lo pake
      const cleanedOutput = output.replace(/,\s*}/g, '}').replace(/,\s*]/g, ']');
      const jsonResponse = JSON.parse(cleanedOutput);

      if (!jsonResponse || jsonResponse.status !== "success") {
        return res.status(500).json({ error: 'apitrial-trojan returned failure', detail: jsonResponse || cleanedOutput });
      }

      // Ambil fields umum dari script Trojan lo
      const data = {
        username: jsonResponse.username || null,
        uuid: jsonResponse.uuid || null,            // script pakai uuid field
        ip: jsonResponse.ip || null,
        domain: jsonResponse.domain || null,
        ns_domain: jsonResponse.ns_domain || null,
        city: jsonResponse.city || null,
        public_key: jsonResponse.public_key || null,
        expiration: jsonResponse.expiration || jsonResponse.exp || null,
        protocol: jsonResponse.protocol || 'trojan',
        link_tls: jsonResponse.link_tls || null,
        link_grpc: jsonResponse.link_grpc || null,
        port_tls: jsonResponse.port_tls || null,
        port_http: jsonResponse.port_http || null,
        dns_port: jsonResponse.dns_port || null,
        grpc_port: jsonResponse.grpc_port || null,
        path: jsonResponse.path || null,
        service_name: jsonResponse.service_name || null
      };

      return res.json({
        status: "success",
        message: "Trojan trial successfully created",
        data
      });
    } catch (err) {
      console.error('Error parsing apitrial-trojan JSON:', err, 'rawOutput:', output);
      return res.status(500).json({ error: 'Terjadi kesalahan saat memproses output JSON', detail: err.message, raw: output });
    }
  });
});

// Create Shadowsocks trial (calls /usr/bin/apitrial-shadowsocks) — cleaned & robust
app.get("/trialshadowsocks", (req, res) => {
  console.log(`Menerima permintaan trial Shadowsocks dari ${req.ip}`);

  const cmd = "/usr/bin/api2trial-shadowsocks";
  const child = spawn("/bin/bash", ["-c", cmd], { stdio: ['pipe','pipe','pipe'] });

  child.stdin.end();
  let output = '';
  child.stdout.on('data', (data) => { output += data.toString(); });
  child.stderr.on('data', (data) => {
    console.error(`apitrial-shadowsocks stderr: ${data}`);
    output += data.toString();
  });

  child.on('close', (code) => {
    if (code !== 0) {
      console.log(`apitrial-shadowsocks exited with code ${code}`);
      return res.status(500).json({ error: 'Terjadi kesalahan saat membuat trial Shadowsocks', detail: output });
    }

    try {
      // bersihkan output: trailing commas + trim + remove weird control chars
      let cleanedOutput = String(output).replace(/\u0000/g, '').trim();
      cleanedOutput = cleanedOutput.replace(/,\s*}/g, '}').replace(/,\s*]/g, ']');

      // parse
      let jsonResponse;
      try {
        jsonResponse = JSON.parse(cleanedOutput);
      } catch (parseErr) {
        console.error('Failed to JSON.parse cleanedOutput:', parseErr, 'cleanedOutput:', cleanedOutput.slice(0,4000));
        return res.status(500).json({ error: 'Gagal parse JSON dari script', detail: parseErr.message, raw: cleanedOutput.slice(0,4000) });
      }

      if (!jsonResponse || jsonResponse.status !== "success") {
        return res.status(500).json({ error: 'apitrial-shadowsocks returned failure', detail: jsonResponse || cleanedOutput });
      }

      // Normalize fields and provide sensible fallbacks
      const link_ws   = jsonResponse.link_ws  || jsonResponse.link || null;
      const link_grpc = jsonResponse.link_grpc || null;
      const link_any  = jsonResponse.link || link_ws || link_grpc || null;
      const expiration = jsonResponse.expiration || jsonResponse.exp || null;

      // Build ports object if script provides separate port fields
      const ports = {};
      if (jsonResponse.port_tls) ports.ssl_tls = String(jsonResponse.port_tls);
      if (jsonResponse.port_http) ports.http = String(jsonResponse.port_http);
      if (jsonResponse.dns_port) ports.dns = String(jsonResponse.dns_port);
      if (jsonResponse.grpc_port) ports.grpc = String(jsonResponse.grpc_port);
      // if ports is empty, set to null to avoid empty object usage confusion
      const portsObj = Object.keys(ports).length ? ports : null;

      // Ambil fields umum dari script Shadowsocks
      const data = {
        username:   jsonResponse.username || null,
        uuid:       jsonResponse.uuid || null,
        password:   jsonResponse.password || null,
        ip:         jsonResponse.ip || null,
        domain:     jsonResponse.domain || null,
        ns_domain:  jsonResponse.ns_domain || null,
        city:       jsonResponse.city || null,
        public_key: jsonResponse.public_key || null,
        expiration: expiration,
        protocol:   jsonResponse.protocol || 'shadowsocks',
        method:     jsonResponse.method || null,
        // expose both specific links + a generic "link" for compatibility
        link:       link_any,
        link_ws:    link_ws,
        link_grpc:  link_grpc,
        port_tls:   jsonResponse.port_tls || null,
        path:       jsonResponse.path || null,
        service_name: jsonResponse.service_name || null,
        // ports object for handlers that expect d.ports
        ports: portsObj
      };

      return res.json({
        status: "success",
        message: "Shadowsocks trial successfully created",
        data
      });
    } catch (err) {
      console.error('Error processing apitrial-shadowsocks output:', err, 'rawOutputSlice:', output.slice(0,4000));
      return res.status(500).json({ error: 'Terjadi kesalahan saat memproses output JSON', detail: err.message, raw: output.slice(0,4000) });
    }
  });
});

const PORT = process.env.PORT || 5888;
app.listen(PORT, () => {
  console.log(`Server berjalan di port ${PORT}`);
});