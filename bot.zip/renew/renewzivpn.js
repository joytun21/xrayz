const axios = require('axios');
const sqlite3 = require('sqlite3').verbose();

// FIX KRITIS: Ganti './sellvpn.db' menjadi './database.db' agar sinkron dengan app.js utama
const db = new sqlite3.Database('./database.db'); 

async function renewzivpn(password, days, iplimit, serverId) {
  console.log(
    `♻️ Renew ZIVPN | Password: ${password} | +${days} days | IP Limit: ${iplimit}`
  );

  if (!password || !days || !iplimit) {
    return '❌ Parameter renew ZIVPN tidak lengkap.';
  }

  return new Promise((resolve) => {
    // Mencari server di database yang benar (database.db)
    db.get('SELECT * FROM Server WHERE id = ?', [serverId], async (err, server) => {
      if (err) {
        console.error('DB Error:', err.message);
        return resolve('❌ Terjadi kesalahan database.');
      }
      
      if (!server) {
        return resolve('❌ Server tidak ditemukan.');
      }

      // Gunakan encodeURIComponent untuk password dan auth agar tidak error jika ada karakter unik
      const url =
        `http://${server.domain}:5888/renewzivpn?` +
        `password=${encodeURIComponent(password)}` +
        `&days=${days}` +
        `&iplimit=${iplimit}` +
        `&auth=${encodeURIComponent(server.auth)}`;

      try {
        const { data } = await axios.get(url, { timeout: 15000 });

        if (data.status !== 'success') {
          return resolve(`❌ Gagal renew ZIVPN: ${data.message || 'unknown error'}`);
        }

        // Ambil data dari response API (sesuai struktur json.data di api.js)
        const d = data.data;

        const msg = `
♻️ *ZIVPN RENEW BERHASIL*

🔹 *Informasi Akun*
┌───────────────────────────
│🌐 Domain   : \`${server.domain}\`
│🔐 Password : \`${d.password || password}\`
│📅 Expired  : \`${d.expired || '-'}\`
│🌍 IP Limit : \`${d.ip_limit || iplimit} IP\`
│📡 Port UDP : \`6000 – 19999\`
└───────────────────────────

✨ Masa aktif berhasil diperpanjang.
`.trim();

        resolve(msg);

      } catch (e) {
        console.error('❌ ZIVPN Renew API error:', e.message);
        resolve('❌ Koneksi API Server gagal atau timeout.');
      }
    });
  });
}

module.exports = { renewzivpn };
