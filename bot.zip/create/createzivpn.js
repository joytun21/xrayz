const axios = require('axios');
const sqlite3 = require('sqlite3').verbose();
// SAMAKAN DENGAN app.js
const db = new sqlite3.Database('./database.db'); 

async function createzivpn(password, exp, iplimit, serverId) {
  return new Promise((resolve) => {
    // Pastikan ID server dikirim dengan benar dari app.js
    db.get('SELECT * FROM Server WHERE id = ?', [serverId], async (err, server) => {
      if (err || !server) {
        return resolve('❌ Server tidak ditemukan di database bot.');
      }

      // Sesuai api.js: /createzivpn?password=...&exp=...&iplimit=...&auth=...
      const url = `http://${server.domain}:5888/createzivpn?password=${encodeURIComponent(password)}&exp=${exp}&iplimit=${iplimit}&auth=${encodeURIComponent(server.auth)}`;

      try {
        const { data } = await axios.get(url, { timeout: 15000 });

        if (data.status !== 'success') {
          return resolve(`❌ Gagal: ${data.message || 'Error API'}`);
        }

        const d = data.data;
        return resolve(`
🌟 *AKUN ZIVPN PREMIUM* 🌟

🔹 *Informasi Akun*
┌───────────────────────────
│🌍 Domain   : \`${server.domain}\`
│🔐 Password : \`${d.password}\`
│📅 Expired  : \`${d.expired}\`
│🌐 IP Limit : \`${d.ip_limit} IP\`
│📡 Port UDP : \`6000 – 19999\`
└───────────────────────────
✨ Akun aktif & siap digunakan
`.trim());

      } catch (e) {
        resolve('❌ API Error: ' + e.message);
      }
    });
  });
}

module.exports = { createzivpn };
